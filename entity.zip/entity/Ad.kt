/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "ad")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Ad.findAll", query = "SELECT a FROM Ad a"))
class Ad : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    var version: Long = 0

    @Basic(optional = false)
    @Column(name = "ad_height")
    var adHeight = 0

    @Basic(optional = false)
    @Column(name = "ad_type")
    var adType: Long = 0

    @Basic(optional = false)
    @Column(name = "ad_width")
    var adWidth = 0

    @Lob
    @Column(name = "headline")
    var headline: String? = null

    @Basic(optional = false)
    @Column(name = "height")
    var height = 0

    @Lob
    @Column(name = "image_link")
    var imageLink: String? = null

    @Basic(optional = false)
    @Column(name = "img_height")
    var imgHeight = 0

    @Basic(optional = false)
    @Column(name = "img_width")
    var imgWidth = 0

    @Basic(optional = false)
    @Column(name = "max_lengthh")
    var maxLengthh = 0

    @Basic(optional = false)
    @Column(name = "max_lengtht")
    var maxLengtht = 0

    @Basic(optional = false)
    @Column(name = "product_id")
    var productId: Long = 0

    @Lob
    @Column(name = "text")
    var text: String? = null

    @Basic(optional = false)
    @Column(name = "width")
    var width = 0

    @Basic(optional = false)
    @Column(name = "x1")
    var x1 = 0

    @Basic(optional = false)
    @Column(name = "x2")
    var x2 = 0

    @Basic(optional = false)
    @Column(name = "y1")
    var y1 = 0

    @Basic(optional = false)
    @Column(name = "y2")
    var y2 = 0

    @Column(name = "image_link_prefix")
    var imageLinkPrefix: String? = null

    @Lob
    @Column(name = "image_source")
    var imageSource: String? = null

    @Column(name = "img_pos")
    var imgPos: String? = null

    @Column(name = "limits")
    var limits: String? = null

    @Column(name = "published")
    var published: Boolean? = null

    @Column(name = "additional_link_one")
    var additionalLinkOne: String? = null

    @Column(name = "additional_link_one_prefix")
    var additionalLinkOnePrefix: String? = null

    @Column(name = "additional_link_one_type")
    var additionalLinkOneType: String? = null

    @Column(name = "additional_link_two")
    var additionalLinkTwo: String? = null

    @Column(name = "additional_link_two_prefix")
    var additionalLinkTwoPrefix: String? = null

    @Column(name = "additional_link_two_type")
    var additionalLinkTwoType: String? = null

    @Lob
    @Column(name = "tracking_pixel_code")
    var trackingPixelCode: String? = null

    //    @XmlTransient
    //    public List<Ad> getAdList() {
    //        return adList;
    //    }
    //
    //    public void setAdList(List<Ad> adList) {
    //        this.adList = adList;
    //    }
    //
    //    @XmlTransient
    //    public List<Ad> getAdList1() {
    //        return adList1;
    //    }
    //
    //    public void setAdList1(List<Ad> adList1) {
    //        this.adList1 = adList1;
    //    }
    //    @JoinTable(name = "ad_newsletter_send", joinColumns = {
    //        @JoinColumn(name = "ad_nss_id", referencedColumnName = "id")}, inverseJoinColumns = {
    //        @JoinColumn(name = "ad_nss_id", referencedColumnName = "id")})
    //    @ManyToMany(fetch = FetchType.LAZY)
    //    private List<Ad> adList;
    //  //  @ManyToMany(mappedBy = "adList", fetch = FetchType.LAZY)
    //    private List<Ad> adList1;
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "additional_link_label_two_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var additionalLinkLabelTwoId: LinkLabel? = null

    @JoinColumn(name = "additional_link_label_one_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var additionalLinkLabelOneId: LinkLabel? = null

    @JoinColumn(name = "image_label_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var imageLabelId: LinkLabel? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var createdById: Useradw? = null

    @JoinColumn(name = "published_by_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var publishedById: Useradw? = null

    @JoinColumn(name = "last_modifier_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var lastModifierId: Useradw? = null

    @OneToMany(mappedBy = "adId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        adHeight: Int,
        adType: Long,
        adWidth: Int,
        height: Int,
        imgHeight: Int,
        imgWidth: Int,
        maxLengthh: Int,
        maxLengtht: Int,
        productId: Long,
        width: Int,
        x1: Int,
        x2: Int,
        y1: Int,
        y2: Int
    ) {
        this.id = id
        this.version = version
        this.adHeight = adHeight
        this.adType = adType
        this.adWidth = adWidth
        this.height = height
        this.imgHeight = imgHeight
        this.imgWidth = imgWidth
        this.maxLengthh = maxLengthh
        this.maxLengtht = maxLengtht
        this.productId = productId
        this.width = width
        this.x1 = x1
        this.x2 = x2
        this.y1 = y1
        this.y2 = y2
    }

//    fun setCustomerId(customerId: Customer?) {
//        field = customerId
//    }
//
//    fun getAdditionalLinkLabelTwoId(): LinkLabel? {
//        return additionalLinkLabelTwoId
//    }
//
//    fun setAdditionalLinkLabelTwoId(additionalLinkLabelTwoId: LinkLabel?) {
//        this.additionalLinkLabelTwoId = additionalLinkLabelTwoId
//    }
//
//    fun getAdditionalLinkLabelOneId(): LinkLabel? {
//        return additionalLinkLabelOneId
//    }
//
//    fun setAdditionalLinkLabelOneId(additionalLinkLabelOneId: LinkLabel?) {
//        this.additionalLinkLabelOneId = additionalLinkLabelOneId
//    }
//
//    fun getImageLabelId(): LinkLabel? {
//        return imageLabelId
//    }
//
//    fun setImageLabelId(imageLabelId: LinkLabel?) {
//        this.imageLabelId = imageLabelId
//    }
//
//    fun getInfoId(): ObjectInfo? {
//        return infoId
//    }
//
//    fun setInfoId(infoId: ObjectInfo?) {
//        this.infoId = infoId
//    }
//
//    fun getCreatedById(): Useradw? {
//        return createdById
//    }
//
//    fun setCreatedById(createdById: Useradw?) {
//        this.createdById = createdById
//    }
//
//    fun getPublishedById(): Useradw? {
//        return publishedById
//    }
//
//    fun setPublishedById(publishedById: Useradw?) {
//        this.publishedById = publishedById
//    }
//
//    fun getLastModifierId(): Useradw? {
//        return lastModifierId
//    }
//
//    fun setLastModifierId(lastModifierId: Useradw?) {
//        this.lastModifierId = lastModifierId
//    }

//    @XmlTransient
//    fun getCustNewsPriceList(): List<CustNewsPrice>? {
//        return custNewsPriceList
//    }
    companion object {
        private const val serialVersionUID = 1L
    }
}
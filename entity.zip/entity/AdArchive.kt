/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigInteger
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "ad_archive")
@XmlRootElement
@NamedQueries(NamedQuery(name = "AdArchive.findAll", query = "SELECT a FROM AdArchive a"))
class AdArchive : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    var version: Long = 0

    @Column(name = "ad_height")
    var adHeight: Int? = null

    @Column(name = "ad_type")
    var adType: BigInteger? = null

    @Column(name = "ad_width")
    var adWidth: Int? = null

    @Lob
    @Column(name = "headline")
    var headline: String? = null

    @Column(name = "height")
    var height: Int? = null

    @Lob
    @Column(name = "image_link")
    var imageLink: String? = null

    @Column(name = "image_link_prefix")
    var imageLinkPrefix: String? = null

    @Lob
    @Column(name = "image_source")
    var imageSource: String? = null

    @Column(name = "img_height")
    var imgHeight: Int? = null

    @Column(name = "img_pos")
    var imgPos: String? = null

    @Column(name = "img_width")
    var imgWidth: Int? = null

    @Column(name = "limits")
    var limits: String? = null

    @Column(name = "max_lengthh")
    var maxLengthh: Int? = null

    @Column(name = "max_lengtht")
    var maxLengtht: Int? = null

    @Column(name = "original_ad_id")
    var originalAdId: BigInteger? = null

    @Column(name = "product_id")
    var productId: BigInteger? = null

    @Column(name = "published")
    var published: Boolean? = null

    @Lob
    @Column(name = "text")
    var text: String? = null

    @Column(name = "width")
    var width: Int? = null

    @Column(name = "x1")
    var x1: Int? = null

    @Column(name = "x2")
    var x2: Int? = null

    @Column(name = "y1")
    var y1: Int? = null

    @Column(name = "y2")
    var y2: Int? = null

    @Column(name = "additional_link_one")
    var additionalLinkOne: String? = null

    @Column(name = "additional_link_one_prefix")
    var additionalLinkOnePrefix: String? = null

    @Column(name = "additional_link_one_type")
    var additionalLinkOneType: String? = null

    @Column(name = "additional_link_two")
    var additionalLinkTwo: String? = null

    @Column(name = "additional_link_two_prefix")
    var additionalLinkTwoPrefix: String? = null

    @Column(name = "additional_link_two_type")
    var additionalLinkTwoType: String? = null

    @Lob
    @Column(name = "tracking_pixel_code")
    var trackingPixelCode: String? = null

    //    @XmlTransient
    //    public List<AdArchive> getAdArchiveList() {
    //        return adArchiveList;
    //    }
    //
    //    public void setAdArchiveList(List<AdArchive> adArchiveList) {
    //        this.adArchiveList = adArchiveList;
    //    }
    //
    //    @XmlTransient
    //    public List<AdArchive> getAdArchiveList1() {
    //        return adArchiveList1;
    //    }
    //
    //    public void setAdArchiveList1(List<AdArchive> adArchiveList1) {
    //        this.adArchiveList1 = adArchiveList1;
    //    }
    //    @JoinTable(name = "ad_archive_newsletter_send", joinColumns = {
    //        @JoinColumn(name = "ad_archive_nss_id", referencedColumnName = "id")}, inverseJoinColumns = {
    //        @JoinColumn(name = "ad_archive_nss_id", referencedColumnName = "id")})
    //    @ManyToMany(fetch = FetchType.LAZY)
    //    private List<AdArchive> adArchiveList;
    //    @ManyToMany(mappedBy = "adArchiveList", fetch = FetchType.LAZY)
    //    private List<AdArchive> adArchiveList1;
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "additional_link_label_one_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var additionalLinkLabelOneId: LinkLabel? = null

    @JoinColumn(name = "additional_link_label_two_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var additionalLinkLabelTwoId: LinkLabel? = null

    @JoinColumn(name = "image_label_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var imageLabelId: LinkLabel? = null

    @JoinColumn(name = "last_modifier_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var lastModifierId: Useradw? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long) {
        this.id = id
        this.version = version
    }

    fun setCustomerId(customerId: Customer?) {
        this.customerId = customerId
    }

    fun getAdditionalLinkLabelOneId(): LinkLabel? {
        return additionalLinkLabelOneId
    }

    fun setAdditionalLinkLabelOneId(additionalLinkLabelOneId: LinkLabel?) {
        this.additionalLinkLabelOneId = additionalLinkLabelOneId
    }

    fun getAdditionalLinkLabelTwoId(): LinkLabel? {
        return additionalLinkLabelTwoId
    }

    fun setAdditionalLinkLabelTwoId(additionalLinkLabelTwoId: LinkLabel?) {
        this.additionalLinkLabelTwoId = additionalLinkLabelTwoId
    }

    fun getImageLabelId(): LinkLabel? {
        return imageLabelId
    }

    fun setImageLabelId(imageLabelId: LinkLabel?) {
        this.imageLabelId = imageLabelId
    }

    fun getLastModifierId(): Useradw? {
        return lastModifierId
    }

    fun setLastModifierId(lastModifierId: Useradw?) {
        this.lastModifierId = lastModifierId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is AdArchive) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.AdArchive[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
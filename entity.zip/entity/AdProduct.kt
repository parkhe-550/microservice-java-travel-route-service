/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "ad_product")
@XmlRootElement
@NamedQueries(NamedQuery(name = "AdProduct.findAll", query = "SELECT a FROM AdProduct a"))
class AdProduct : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "description")
    private var description: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "type")
    private var type: Int? = null

    @Column(name = "is_active")
    private var isActive: Boolean? = null

    @Column(name = "height")
    private var height: Int? = null

    @Column(name = "width")
    private var width: Int? = null

    @Column(name = "position")
    private var position: Int? = null

    @OneToMany(mappedBy = "adProductId", fetch = FetchType.LAZY)
    private var mediaSuiteAdProductList: List<MediaSuiteAdProduct>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "adProductId", fetch = FetchType.LAZY)
    private var pricingModelList: List<PricingModel>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "adProductId", fetch = FetchType.LAZY)
    private var thirdPartyList: List<ThirdParty>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "productId", fetch = FetchType.LAZY)
    private var newsxproductList: List<Newsxproduct>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "adProductId", fetch = FetchType.LAZY)
    private var meSoList: List<MeSo>? = null

    @OneToMany(mappedBy = "adProductId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, description: String?, name: String?) {
        this.id = id
        this.version = version
        this.description = description
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getDescription(): String? {
        return description
    }

    fun setDescription(description: String?) {
        this.description = description
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getType(): Int? {
        return type
    }

    fun setType(type: Int?) {
        this.type = type
    }

    fun getIsActive(): Boolean? {
        return isActive
    }

    fun setIsActive(isActive: Boolean?) {
        this.isActive = isActive
    }

    fun getHeight(): Int? {
        return height
    }

    fun setHeight(height: Int?) {
        this.height = height
    }

    fun getWidth(): Int? {
        return width
    }

    fun setWidth(width: Int?) {
        this.width = width
    }

    fun getPosition(): Int? {
        return position
    }

    fun setPosition(position: Int?) {
        this.position = position
    }

    @XmlTransient
    fun getMediaSuiteAdProductList(): List<MediaSuiteAdProduct>? {
        return mediaSuiteAdProductList
    }

    fun setMediaSuiteAdProductList(mediaSuiteAdProductList: List<MediaSuiteAdProduct>?) {
        this.mediaSuiteAdProductList = mediaSuiteAdProductList
    }

    @XmlTransient
    fun getPricingModelList(): List<PricingModel>? {
        return pricingModelList
    }

    fun setPricingModelList(pricingModelList: List<PricingModel>?) {
        this.pricingModelList = pricingModelList
    }

    @XmlTransient
    fun getThirdPartyList(): List<ThirdParty>? {
        return thirdPartyList
    }

    fun setThirdPartyList(thirdPartyList: List<ThirdParty>?) {
        this.thirdPartyList = thirdPartyList
    }

    @XmlTransient
    fun getNewsxproductList(): List<Newsxproduct>? {
        return newsxproductList
    }

    fun setNewsxproductList(newsxproductList: List<Newsxproduct>?) {
        this.newsxproductList = newsxproductList
    }

    @XmlTransient
    fun getMeSoList(): List<MeSo>? {
        return meSoList
    }

    fun setMeSoList(meSoList: List<MeSo>?) {
        this.meSoList = meSoList
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is AdProduct) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.AdProduct[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
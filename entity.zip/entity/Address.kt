/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "address")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Address.findAll", query = "SELECT a FROM Address a"))
class Address : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "city")
    private var city: String? = null

    @Column(name = "country")
    private var country: String? = null

    @Column(name = "fax")
    private var fax: String? = null

    @Column(name = "phone")
    private var phone: String? = null

    @Column(name = "street")
    private var street: String? = null

    @Column(name = "zipcode")
    private var zipcode: String? = null

    @Column(name = "state")
    private var state: String? = null

    @OneToMany(mappedBy = "addressId")
    private var officeList: List<Office>? = null

    @JoinColumn(name = "country_id", referencedColumnName = "id")
    @ManyToOne
    private var countryId: Country? = null

    @OneToMany(mappedBy = "addressId")
    private var customerList: List<Customer>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long) {
        this.id = id
        this.version = version
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getCity(): String? {
        return city
    }

    fun setCity(city: String?) {
        this.city = city
    }

    fun getCountry(): String? {
        return country
    }

    fun setCountry(country: String?) {
        this.country = country
    }

    fun getFax(): String? {
        return fax
    }

    fun setFax(fax: String?) {
        this.fax = fax
    }

    fun getPhone(): String? {
        return phone
    }

    fun setPhone(phone: String?) {
        this.phone = phone
    }

    fun getStreet(): String? {
        return street
    }

    fun setStreet(street: String?) {
        this.street = street
    }

    fun getZipcode(): String? {
        return zipcode
    }

    fun setZipcode(zipcode: String?) {
        this.zipcode = zipcode
    }

    fun getState(): String? {
        return state
    }

    fun setState(state: String?) {
        this.state = state
    }

    @XmlTransient
    fun getOfficeList(): List<Office>? {
        return officeList
    }

    fun setOfficeList(officeList: List<Office>?) {
        this.officeList = officeList
    }

    fun getCountryId(): Country? {
        return countryId
    }

    fun setCountryId(countryId: Country?) {
        this.countryId = countryId
    }

    @XmlTransient
    fun getCustomerList(): List<Customer>? {
        return customerList
    }

    fun setCustomerList(customerList: List<Customer>?) {
        this.customerList = customerList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Address) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Address[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "approval_log")
@XmlRootElement
@NamedQueries(NamedQuery(name = "ApprovalLog.findAll", query = "SELECT a FROM ApprovalLog a"))
class ApprovalLog : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "comment")
    private var comment: String? = null

    @Column(name = "date_approved")
    @Temporal(TemporalType.TIMESTAMP)
    private var dateApproved: Date? = null

    @Column(name = "date_sent")
    @Temporal(TemporalType.TIMESTAMP)
    private var dateSent: Date? = null

    @Basic(optional = false)
    @Column(name = "is_approved")
    private var isApproved = false

    @Basic(optional = false)
    @Column(name = "type")
    private var type: String? = null

    @JoinColumn(name = "approver_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var approverId: Useradw? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, isApproved: Boolean, type: String?) {
        this.id = id
        this.version = version
        this.isApproved = isApproved
        this.type = type
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getComment(): String? {
        return comment
    }

    fun setComment(comment: String?) {
        this.comment = comment
    }

    fun getDateApproved(): Date? {
        return dateApproved
    }

    fun setDateApproved(dateApproved: Date?) {
        this.dateApproved = dateApproved
    }

    fun getDateSent(): Date? {
        return dateSent
    }

    fun setDateSent(dateSent: Date?) {
        this.dateSent = dateSent
    }

    fun getIsApproved(): Boolean {
        return isApproved
    }

    fun setIsApproved(isApproved: Boolean) {
        this.isApproved = isApproved
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getApproverId(): Useradw? {
        return approverId
    }

    fun setApproverId(approverId: Useradw?) {
        this.approverId = approverId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is ApprovalLog) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.ApprovalLog[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "campaign")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Campaign.findAll", query = "SELECT c FROM Campaign c"))
class Campaign : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "active")
    private var active = false

    @Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var endDate: Date? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Basic(optional = false)
    @Column(name = "soldpi")
    private var soldpi: Long = 0

    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var startDate: Date? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "tkp")
    private var tkp: BigDecimal? = null

    @Column(name = "fixed_price")
    private var fixedPrice: BigDecimal? = null

    @Column(name = "hide")
    private var hide: Boolean? = null

    @Column(name = "sales_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var salesDate: Date? = null

    @Column(name = "invoice_number")
    private var invoiceNumber: String? = null

    @Column(name = "order_number")
    private var orderNumber: String? = null

    @Column(name = "kpi")
    private var kpi: Int? = null

    @Basic(optional = false)
    @Column(name = "dartpi")
    private var dartpi: Long = 0

    @Column(name = "agency_discount")
    private var agencyDiscount: BigDecimal? = null

    @Column(name = "discount")
    private var discount: BigDecimal? = null

    @Column(name = "gross_amount")
    private var grossAmount: BigDecimal? = null

    @Column(name = "invoice_to")
    private var invoiceTo: String? = null

    @Column(name = "po_number")
    private var poNumber: String? = null

    @Column(name = "product")
    private var product: String? = null

    @Column(name = "subject")
    private var subject: String? = null

    @Column(name = "is_archived")
    private var isArchived: Boolean? = null

    @Column(name = "is_cancelled")
    private var isCancelled: Boolean? = null

    @Column(name = "total_clicks_delivered")
    private var totalClicksDelivered: BigInteger? = null

    @Column(name = "report")
    private var report: String? = null

    @Column(name = "report_remark")
    private var reportRemark: String? = null

    @Column(name = "status")
    private var status: String? = null

    @Column(name = "exclusive_discount")
    private var exclusiveDiscount: BigDecimal? = null

    @Column(name = "non_discountable")
    private var nonDiscountable: BigDecimal? = null

    @Column(name = "bundle_type")
    private var bundleType: String? = null

    @Column(name = "campaign_version")
    private var campaignVersion: Int? = null

    @Lob
    @Column(name = "notes")
    private var notes: String? = null

    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var branchId: Branch? = null

    @JoinColumn(name = "bundle_campaign_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var bundleCampaignId: BundleCampaign? = null

    @JoinColumn(name = "business_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var businessId: Business? = null

    @JoinColumn(name = "agency_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var agencyId: Customer? = null

    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "ad_ops_user_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adOpsUserId: User? = null

    @JoinColumn(name = "salesman_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var salesmanId: User? = null

    @JoinColumn(name = "website_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var websiteId: Website? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, active: Boolean, name: String?, soldpi: Long, dartpi: Long) {
        this.id = id
        this.version = version
        this.active = active
        this.name = name
        this.soldpi = soldpi
        this.dartpi = dartpi
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getActive(): Boolean {
        return active
    }

    fun setActive(active: Boolean) {
        this.active = active
    }

    fun getEndDate(): Date? {
        return endDate
    }

    fun setEndDate(endDate: Date?) {
        this.endDate = endDate
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getSoldpi(): Long {
        return soldpi
    }

    fun setSoldpi(soldpi: Long) {
        this.soldpi = soldpi
    }

    fun getStartDate(): Date? {
        return startDate
    }

    fun setStartDate(startDate: Date?) {
        this.startDate = startDate
    }

    fun getTkp(): BigDecimal? {
        return tkp
    }

    fun setTkp(tkp: BigDecimal?) {
        this.tkp = tkp
    }

    fun getFixedPrice(): BigDecimal? {
        return fixedPrice
    }

    fun setFixedPrice(fixedPrice: BigDecimal?) {
        this.fixedPrice = fixedPrice
    }

    fun getHide(): Boolean? {
        return hide
    }

    fun setHide(hide: Boolean?) {
        this.hide = hide
    }

    fun getSalesDate(): Date? {
        return salesDate
    }

    fun setSalesDate(salesDate: Date?) {
        this.salesDate = salesDate
    }

    fun getInvoiceNumber(): String? {
        return invoiceNumber
    }

    fun setInvoiceNumber(invoiceNumber: String?) {
        this.invoiceNumber = invoiceNumber
    }

    fun getOrderNumber(): String? {
        return orderNumber
    }

    fun setOrderNumber(orderNumber: String?) {
        this.orderNumber = orderNumber
    }

    fun getKpi(): Int? {
        return kpi
    }

    fun setKpi(kpi: Int?) {
        this.kpi = kpi
    }

    fun getDartpi(): Long {
        return dartpi
    }

    fun setDartpi(dartpi: Long) {
        this.dartpi = dartpi
    }

    fun getAgencyDiscount(): BigDecimal? {
        return agencyDiscount
    }

    fun setAgencyDiscount(agencyDiscount: BigDecimal?) {
        this.agencyDiscount = agencyDiscount
    }

    fun getDiscount(): BigDecimal? {
        return discount
    }

    fun setDiscount(discount: BigDecimal?) {
        this.discount = discount
    }

    fun getGrossAmount(): BigDecimal? {
        return grossAmount
    }

    fun setGrossAmount(grossAmount: BigDecimal?) {
        this.grossAmount = grossAmount
    }

    fun getInvoiceTo(): String? {
        return invoiceTo
    }

    fun setInvoiceTo(invoiceTo: String?) {
        this.invoiceTo = invoiceTo
    }

    fun getPoNumber(): String? {
        return poNumber
    }

    fun setPoNumber(poNumber: String?) {
        this.poNumber = poNumber
    }

    fun getProduct(): String? {
        return product
    }

    fun setProduct(product: String?) {
        this.product = product
    }

    fun getSubject(): String? {
        return subject
    }

    fun setSubject(subject: String?) {
        this.subject = subject
    }

    fun getIsArchived(): Boolean? {
        return isArchived
    }

    fun setIsArchived(isArchived: Boolean?) {
        this.isArchived = isArchived
    }

    fun getIsCancelled(): Boolean? {
        return isCancelled
    }

    fun setIsCancelled(isCancelled: Boolean?) {
        this.isCancelled = isCancelled
    }

    fun getTotalClicksDelivered(): BigInteger? {
        return totalClicksDelivered
    }

    fun setTotalClicksDelivered(totalClicksDelivered: BigInteger?) {
        this.totalClicksDelivered = totalClicksDelivered
    }

    fun getReport(): String? {
        return report
    }

    fun setReport(report: String?) {
        this.report = report
    }

    fun getReportRemark(): String? {
        return reportRemark
    }

    fun setReportRemark(reportRemark: String?) {
        this.reportRemark = reportRemark
    }

    fun getStatus(): String? {
        return status
    }

    fun setStatus(status: String?) {
        this.status = status
    }

    fun getExclusiveDiscount(): BigDecimal? {
        return exclusiveDiscount
    }

    fun setExclusiveDiscount(exclusiveDiscount: BigDecimal?) {
        this.exclusiveDiscount = exclusiveDiscount
    }

    fun getNonDiscountable(): BigDecimal? {
        return nonDiscountable
    }

    fun setNonDiscountable(nonDiscountable: BigDecimal?) {
        this.nonDiscountable = nonDiscountable
    }

    fun getBundleType(): String? {
        return bundleType
    }

    fun setBundleType(bundleType: String?) {
        this.bundleType = bundleType
    }

    fun getCampaignVersion(): Int? {
        return campaignVersion
    }

    fun setCampaignVersion(campaignVersion: Int?) {
        this.campaignVersion = campaignVersion
    }

    fun getNotes(): String? {
        return notes
    }

    fun setNotes(notes: String?) {
        this.notes = notes
    }

    fun getBranchId(): Branch? {
        return branchId
    }

    fun setBranchId(branchId: Branch?) {
        this.branchId = branchId
    }

    fun getBundleCampaignId(): BundleCampaign? {
        return bundleCampaignId
    }

    fun setBundleCampaignId(bundleCampaignId: BundleCampaign?) {
        this.bundleCampaignId = bundleCampaignId
    }

    fun getBusinessId(): Business? {
        return businessId
    }

    fun setBusinessId(businessId: Business?) {
        this.businessId = businessId
    }

    fun getAgencyId(): Customer? {
        return agencyId
    }

    fun setAgencyId(agencyId: Customer?) {
        this.agencyId = agencyId
    }

    fun getCustomerId(): Customer? {
        return customerId
    }

    fun setCustomerId(customerId: Customer?) {
        this.customerId = customerId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getAdOpsUserId(): User? {
        return adOpsUserId
    }

    fun setAdOpsUserId(adOpsUserId: User?) {
        this.adOpsUserId = adOpsUserId
    }

    fun getSalesmanId(): User? {
        return salesmanId
    }

    fun setSalesmanId(salesmanId: User?) {
        this.salesmanId = salesmanId
    }

    fun getWebsiteId(): Website? {
        return websiteId
    }

    fun setWebsiteId(websiteId: Website?) {
        this.websiteId = websiteId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Campaign) {
            return false
        }
        val other = `object`
        return if ((id == null && other.id != null || id != null) && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Campaign[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
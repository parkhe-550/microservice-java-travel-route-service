/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "category")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Category.findAll", query = "SELECT c FROM Category c"))
class Category : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "value")
    private var value: String? = null

    @Basic(optional = false)
    @Column(name = "type")
    private var type: String? = null

    @Lob
    @Column(name = "description")
    private var description: String? = null

    @Column(name = "label")
    private var label: String? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "categoryId", fetch = FetchType.LAZY)
    private var fileResourceRefList: List<FileResourceRef>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, value: String?, type: String?) {
        this.id = id
        this.version = version
        this.value = value
        this.type = type
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getValue(): String? {
        return value
    }

    fun setValue(value: String?) {
        this.value = value
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getDescription(): String? {
        return description
    }

    fun setDescription(description: String?) {
        this.description = description
    }

    fun getLabel(): String? {
        return label
    }

    fun setLabel(label: String?) {
        this.label = label
    }

    @XmlTransient
    fun getFileResourceRefList(): List<FileResourceRef>? {
        return fileResourceRefList
    }

    fun setFileResourceRefList(fileResourceRefList: List<FileResourceRef>?) {
        this.fileResourceRefList = fileResourceRefList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Category) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Category[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
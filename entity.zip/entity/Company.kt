/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "company")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Company.findAll", query = "SELECT c FROM Company c"))
class Company : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @OneToMany(mappedBy = "companyId", fetch = FetchType.LAZY)
    private var officeList: List<Office>? = null

    @JoinColumn(name = "country_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var countryId: Country? = null

    @JoinColumn(name = "division_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var divisionId: Devision? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, name: String?) {
        this.id = id
        this.version = version
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    @XmlTransient
    fun getOfficeList(): List<Office>? {
        return officeList
    }

    fun setOfficeList(officeList: List<Office>?) {
        this.officeList = officeList
    }

    fun getCountryId(): Country? {
        return countryId
    }

    fun setCountryId(countryId: Country?) {
        this.countryId = countryId
    }

    fun getDivisionId(): Devision? {
        return divisionId
    }

    fun setDivisionId(divisionId: Devision?) {
        this.divisionId = divisionId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Company) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Company[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
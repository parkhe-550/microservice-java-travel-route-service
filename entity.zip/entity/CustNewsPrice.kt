/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "cust_news_price")
@XmlRootElement
@NamedQueries(NamedQuery(name = "CustNewsPrice.findAll", query = "SELECT c FROM CustNewsPrice c"))
class CustNewsPrice : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "price")
    private var price: BigDecimal? = null

    @Column(name = "new_customer_name")
    private var newCustomerName: String? = null

    @Column(name = "sold_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var soldDate: Date? = null

    @Column(name = "invoice_number")
    private var invoiceNumber: String? = null

    @Column(name = "order_number")
    private var orderNumber: String? = null

    @Column(name = "position")
    private var position: Int? = null

    @Column(name = "is_archived")
    private var isArchived: Boolean? = null

    @Column(name = "is_cancelled")
    private var isCancelled: Boolean? = null

    @Column(name = "concept")
    private var concept: BigDecimal? = null

    @Column(name = "content")
    private var content: BigDecimal? = null

    @Column(name = "diverse")
    private var diverse: BigDecimal? = null

    @Column(name = "gross_clicks")
    private var grossClicks: BigInteger? = null

    @Column(name = "gross_ctr")
    private var grossCtr: BigDecimal? = null

    @Column(name = "gross_opening_rate")
    private var grossOpeningRate: BigDecimal? = null

    @Column(name = "gross_openings")
    private var grossOpenings: BigInteger? = null

    @Column(name = "gross_subscribers")
    private var grossSubscribers: BigInteger? = null

    @Column(name = "net_clicks")
    private var netClicks: BigInteger? = null

    @Column(name = "net_ctr")
    private var netCtr: BigDecimal? = null

    @Column(name = "net_opening_rate")
    private var netOpeningRate: BigDecimal? = null

    @Column(name = "net_openings")
    private var netOpenings: BigInteger? = null

    @Column(name = "net_subscribers")
    private var netSubscribers: BigInteger? = null

    @Column(name = "report")
    private var report: String? = null

    @Column(name = "report_remark")
    private var reportRemark: String? = null

    @Column(name = "report_send_out_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var reportSendOutDate: Date? = null

    @Column(name = "is_excluded_from_report")
    private var isExcludedFromReport: Boolean? = null

    @Lob
    @Column(name = "ad_gapid")
    private var adGapid: String? = null

    @Lob
    @Column(name = "remark")
    private var remark: String? = null

    @Column(name = "type")
    private var type: String? = null

    @JoinColumn(name = "ad_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adId: Ad? = null

    @JoinColumn(name = "ad_product_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adProductId: AdProduct? = null

    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "first_run_stats_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var firstRunStatsId: LineItemStatistics? = null

    @JoinColumn(name = "second_run_stats_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var secondRunStatsId: LineItemStatistics? = null

    @JoinColumn(name = "offer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var offerId: MyNewsletterOffer? = null

    @JoinColumn(name = "newsletter_offer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var newsletterOfferId: NewsletterOffer? = null

    @JoinColumn(name = "status_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var statusId: NewsletterStatus? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "salesman_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var salesmanId: User? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, price: BigDecimal?) {
        this.id = id
        this.version = version
        this.price = price
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getPrice(): BigDecimal? {
        return price
    }

    fun setPrice(price: BigDecimal?) {
        this.price = price
    }

    fun getNewCustomerName(): String? {
        return newCustomerName
    }

    fun setNewCustomerName(newCustomerName: String?) {
        this.newCustomerName = newCustomerName
    }

    fun getSoldDate(): Date? {
        return soldDate
    }

    fun setSoldDate(soldDate: Date?) {
        this.soldDate = soldDate
    }

    fun getInvoiceNumber(): String? {
        return invoiceNumber
    }

    fun setInvoiceNumber(invoiceNumber: String?) {
        this.invoiceNumber = invoiceNumber
    }

    fun getOrderNumber(): String? {
        return orderNumber
    }

    fun setOrderNumber(orderNumber: String?) {
        this.orderNumber = orderNumber
    }

    fun getPosition(): Int? {
        return position
    }

    fun setPosition(position: Int?) {
        this.position = position
    }

    fun getIsArchived(): Boolean? {
        return isArchived
    }

    fun setIsArchived(isArchived: Boolean?) {
        this.isArchived = isArchived
    }

    fun getIsCancelled(): Boolean? {
        return isCancelled
    }

    fun setIsCancelled(isCancelled: Boolean?) {
        this.isCancelled = isCancelled
    }

    fun getConcept(): BigDecimal? {
        return concept
    }

    fun setConcept(concept: BigDecimal?) {
        this.concept = concept
    }

    fun getContent(): BigDecimal? {
        return content
    }

    fun setContent(content: BigDecimal?) {
        this.content = content
    }

    fun getDiverse(): BigDecimal? {
        return diverse
    }

    fun setDiverse(diverse: BigDecimal?) {
        this.diverse = diverse
    }

    fun getGrossClicks(): BigInteger? {
        return grossClicks
    }

    fun setGrossClicks(grossClicks: BigInteger?) {
        this.grossClicks = grossClicks
    }

    fun getGrossCtr(): BigDecimal? {
        return grossCtr
    }

    fun setGrossCtr(grossCtr: BigDecimal?) {
        this.grossCtr = grossCtr
    }

    fun getGrossOpeningRate(): BigDecimal? {
        return grossOpeningRate
    }

    fun setGrossOpeningRate(grossOpeningRate: BigDecimal?) {
        this.grossOpeningRate = grossOpeningRate
    }

    fun getGrossOpenings(): BigInteger? {
        return grossOpenings
    }

    fun setGrossOpenings(grossOpenings: BigInteger?) {
        this.grossOpenings = grossOpenings
    }

    fun getGrossSubscribers(): BigInteger? {
        return grossSubscribers
    }

    fun setGrossSubscribers(grossSubscribers: BigInteger?) {
        this.grossSubscribers = grossSubscribers
    }

    fun getNetClicks(): BigInteger? {
        return netClicks
    }

    fun setNetClicks(netClicks: BigInteger?) {
        this.netClicks = netClicks
    }

    fun getNetCtr(): BigDecimal? {
        return netCtr
    }

    fun setNetCtr(netCtr: BigDecimal?) {
        this.netCtr = netCtr
    }

    fun getNetOpeningRate(): BigDecimal? {
        return netOpeningRate
    }

    fun setNetOpeningRate(netOpeningRate: BigDecimal?) {
        this.netOpeningRate = netOpeningRate
    }

    fun getNetOpenings(): BigInteger? {
        return netOpenings
    }

    fun setNetOpenings(netOpenings: BigInteger?) {
        this.netOpenings = netOpenings
    }

    fun getNetSubscribers(): BigInteger? {
        return netSubscribers
    }

    fun setNetSubscribers(netSubscribers: BigInteger?) {
        this.netSubscribers = netSubscribers
    }

    fun getReport(): String? {
        return report
    }

    fun setReport(report: String?) {
        this.report = report
    }

    fun getReportRemark(): String? {
        return reportRemark
    }

    fun setReportRemark(reportRemark: String?) {
        this.reportRemark = reportRemark
    }

    fun getReportSendOutDate(): Date? {
        return reportSendOutDate
    }

    fun setReportSendOutDate(reportSendOutDate: Date?) {
        this.reportSendOutDate = reportSendOutDate
    }

    fun getIsExcludedFromReport(): Boolean? {
        return isExcludedFromReport
    }

    fun setIsExcludedFromReport(isExcludedFromReport: Boolean?) {
        this.isExcludedFromReport = isExcludedFromReport
    }

    fun getAdGapid(): String? {
        return adGapid
    }

    fun setAdGapid(adGapid: String?) {
        this.adGapid = adGapid
    }

    fun getRemark(): String? {
        return remark
    }

    fun setRemark(remark: String?) {
        this.remark = remark
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getAdId(): Ad? {
        return adId
    }

    fun setAdId(adId: Ad?) {
        this.adId = adId
    }

    fun getAdProductId(): AdProduct? {
        return adProductId
    }

    fun setAdProductId(adProductId: AdProduct?) {
        this.adProductId = adProductId
    }

    fun getCustomerId(): Customer? {
        return customerId
    }

    fun setCustomerId(customerId: Customer?) {
        this.customerId = customerId
    }

    fun getFirstRunStatsId(): LineItemStatistics? {
        return firstRunStatsId
    }

    fun setFirstRunStatsId(firstRunStatsId: LineItemStatistics?) {
        this.firstRunStatsId = firstRunStatsId
    }

    fun getSecondRunStatsId(): LineItemStatistics? {
        return secondRunStatsId
    }

    fun setSecondRunStatsId(secondRunStatsId: LineItemStatistics?) {
        this.secondRunStatsId = secondRunStatsId
    }

    fun getOfferId(): MyNewsletterOffer? {
        return offerId
    }

    fun setOfferId(offerId: MyNewsletterOffer?) {
        this.offerId = offerId
    }

    fun getNewsletterOfferId(): NewsletterOffer? {
        return newsletterOfferId
    }

    fun setNewsletterOfferId(newsletterOfferId: NewsletterOffer?) {
        this.newsletterOfferId = newsletterOfferId
    }

    fun getStatusId(): NewsletterStatus? {
        return statusId
    }

    fun setStatusId(statusId: NewsletterStatus?) {
        this.statusId = statusId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getSalesmanId(): User? {
        return salesmanId
    }

    fun setSalesmanId(salesmanId: User?) {
        this.salesmanId = salesmanId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is CustNewsPrice) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.CustNewsPrice[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
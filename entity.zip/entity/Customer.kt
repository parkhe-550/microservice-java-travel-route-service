/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigInteger
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "customer")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c"))
class Customer : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "contact_person")
    private var contactPerson: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "ident_key")
    private var identKey: String? = null

    @Column(name = "is_active")
    private var isActive: Boolean? = null

    @Column(name = "is_agency")
    private var isAgency: Boolean? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "discount")
    private var discount: Double? = null

    @Column(name = "abbreviation")
    private var abbreviation: String? = null

    @Column(name = "group_email")
    private var groupEmail: String? = null

    @Column(name = "other_emails")
    private var otherEmails: String? = null

    @Column(name = "code")
    private var code: String? = null

    @Column(name = "is_ad_gapidactive")
    private var isAdGapidactive: Boolean? = null

    @Column(name = "ad_gapid")
    private var adGapid: BigInteger? = null

    @Column(name = "approval_reminder_email")
    private var approvalReminderEmail: String? = null

    @OneToMany(mappedBy = "agencyId")
    private var otherProductsList: List<OtherProducts>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "customerId")
    private var otherProductsList1: List<OtherProducts>? = null

    @OneToMany(mappedBy = "customerId")
    private var adArchiveList: List<AdArchive>? = null

    @OneToMany(mappedBy = "customerId")
    private var adList: List<Ad>? = null

    @OneToMany(mappedBy = "customerId")
    private var newsletterOfferList: List<NewsletterOffer>? = null

    @OneToMany(mappedBy = "agencyId")
    private var newsletterOfferList1: List<NewsletterOffer>? = null

    @OneToMany(mappedBy = "agencyId")
    private var campaignList: List<Campaign>? = null

    @OneToMany(mappedBy = "customerId")
    private var campaignList1: List<Campaign>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "thirdPartyId")
    private var thirdPartyList: List<ThirdParty>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "customerId")
    private var meSoList: List<MeSo>? = null

    @OneToMany(mappedBy = "agencyId")
    private var meSoList1: List<MeSo>? = null

    @OneToMany(mappedBy = "customerId")
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @JoinColumn(name = "address_id", referencedColumnName = "id")
    @ManyToOne
    private var addressId: Address? = null

    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    @ManyToOne
    private var branchId: Branch? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, name: String?) {
        this.id = id
        this.version = version
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getContactPerson(): String? {
        return contactPerson
    }

    fun setContactPerson(contactPerson: String?) {
        this.contactPerson = contactPerson
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getIdentKey(): String? {
        return identKey
    }

    fun setIdentKey(identKey: String?) {
        this.identKey = identKey
    }

    fun getIsActive(): Boolean? {
        return isActive
    }

    fun setIsActive(isActive: Boolean?) {
        this.isActive = isActive
    }

    fun getIsAgency(): Boolean? {
        return isAgency
    }

    fun setIsAgency(isAgency: Boolean?) {
        this.isAgency = isAgency
    }

    fun getDiscount(): Double? {
        return discount
    }

    fun setDiscount(discount: Double?) {
        this.discount = discount
    }

    fun getAbbreviation(): String? {
        return abbreviation
    }

    fun setAbbreviation(abbreviation: String?) {
        this.abbreviation = abbreviation
    }

    fun getGroupEmail(): String? {
        return groupEmail
    }

    fun setGroupEmail(groupEmail: String?) {
        this.groupEmail = groupEmail
    }

    fun getOtherEmails(): String? {
        return otherEmails
    }

    fun setOtherEmails(otherEmails: String?) {
        this.otherEmails = otherEmails
    }

    fun getCode(): String? {
        return code
    }

    fun setCode(code: String?) {
        this.code = code
    }

    fun getIsAdGapidactive(): Boolean? {
        return isAdGapidactive
    }

    fun setIsAdGapidactive(isAdGapidactive: Boolean?) {
        this.isAdGapidactive = isAdGapidactive
    }

    fun getAdGapid(): BigInteger? {
        return adGapid
    }

    fun setAdGapid(adGapid: BigInteger?) {
        this.adGapid = adGapid
    }

    fun getApprovalReminderEmail(): String? {
        return approvalReminderEmail
    }

    fun setApprovalReminderEmail(approvalReminderEmail: String?) {
        this.approvalReminderEmail = approvalReminderEmail
    }

    @XmlTransient
    fun getOtherProductsList(): List<OtherProducts>? {
        return otherProductsList
    }

    fun setOtherProductsList(otherProductsList: List<OtherProducts>?) {
        this.otherProductsList = otherProductsList
    }

    @XmlTransient
    fun getOtherProductsList1(): List<OtherProducts>? {
        return otherProductsList1
    }

    fun setOtherProductsList1(otherProductsList1: List<OtherProducts>?) {
        this.otherProductsList1 = otherProductsList1
    }

    @XmlTransient
    fun getAdArchiveList(): List<AdArchive>? {
        return adArchiveList
    }

    fun setAdArchiveList(adArchiveList: List<AdArchive>?) {
        this.adArchiveList = adArchiveList
    }

    @XmlTransient
    fun getAdList(): List<Ad>? {
        return adList
    }

    fun setAdList(adList: List<Ad>?) {
        this.adList = adList
    }

    @XmlTransient
    fun getNewsletterOfferList(): List<NewsletterOffer>? {
        return newsletterOfferList
    }

    fun setNewsletterOfferList(newsletterOfferList: List<NewsletterOffer>?) {
        this.newsletterOfferList = newsletterOfferList
    }

    @XmlTransient
    fun getNewsletterOfferList1(): List<NewsletterOffer>? {
        return newsletterOfferList1
    }

    fun setNewsletterOfferList1(newsletterOfferList1: List<NewsletterOffer>?) {
        this.newsletterOfferList1 = newsletterOfferList1
    }

    @XmlTransient
    fun getCampaignList(): List<Campaign>? {
        return campaignList
    }

    fun setCampaignList(campaignList: List<Campaign>?) {
        this.campaignList = campaignList
    }

    @XmlTransient
    fun getCampaignList1(): List<Campaign>? {
        return campaignList1
    }

    fun setCampaignList1(campaignList1: List<Campaign>?) {
        this.campaignList1 = campaignList1
    }

    @XmlTransient
    fun getThirdPartyList(): List<ThirdParty>? {
        return thirdPartyList
    }

    fun setThirdPartyList(thirdPartyList: List<ThirdParty>?) {
        this.thirdPartyList = thirdPartyList
    }

    @XmlTransient
    fun getMeSoList(): List<MeSo>? {
        return meSoList
    }

    fun setMeSoList(meSoList: List<MeSo>?) {
        this.meSoList = meSoList
    }

    @XmlTransient
    fun getMeSoList1(): List<MeSo>? {
        return meSoList1
    }

    fun setMeSoList1(meSoList1: List<MeSo>?) {
        this.meSoList1 = meSoList1
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    fun getAddressId(): Address? {
        return addressId
    }

    fun setAddressId(addressId: Address?) {
        this.addressId = addressId
    }

    fun getBranchId(): Branch? {
        return branchId
    }

    fun setBranchId(branchId: Branch?) {
        this.branchId = branchId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Customer) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Customer[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
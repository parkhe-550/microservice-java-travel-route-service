/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "date_based_subscribers_and_fixed_cost")
@XmlRootElement
@NamedQueries(
    NamedQuery(
        name = "DateBasedSubscribersAndFixedCost.findAll",
        query = "SELECT d FROM DateBasedSubscribersAndFixedCost d"
    )
)
class DateBasedSubscribersAndFixedCost : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "fixed_price")
    private var fixedPrice: BigDecimal? = null

    @Column(name = "subscription")
    private var subscription: BigInteger? = null

    @Column(name = "ceiling_price")
    private var ceilingPrice: BigDecimal? = null

    @JoinColumn(name = "date_range_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var dateRangeId: GeneralDateRange? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long) {
        this.id = id
        this.version = version
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getFixedPrice(): BigDecimal? {
        return fixedPrice
    }

    fun setFixedPrice(fixedPrice: BigDecimal?) {
        this.fixedPrice = fixedPrice
    }

    fun getSubscription(): BigInteger? {
        return subscription
    }

    fun setSubscription(subscription: BigInteger?) {
        this.subscription = subscription
    }

    fun getCeilingPrice(): BigDecimal? {
        return ceilingPrice
    }

    fun setCeilingPrice(ceilingPrice: BigDecimal?) {
        this.ceilingPrice = ceilingPrice
    }

    fun getDateRangeId(): GeneralDateRange? {
        return dateRangeId
    }

    fun setDateRangeId(dateRangeId: GeneralDateRange?) {
        this.dateRangeId = dateRangeId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is DateBasedSubscribersAndFixedCost) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.DateBasedSubscribersAndFixedCost[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
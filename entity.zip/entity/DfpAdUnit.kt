/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "dfp_ad_unit")
@XmlRootElement
@NamedQueries(NamedQuery(name = "DfpAdUnit.findAll", query = "SELECT d FROM DfpAdUnit d"))
class DfpAdUnit : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "description")
    private var description: String? = null

    @Basic(optional = false)
    @Column(name = "dfp_id")
    private var dfpId: String? = null

    @Basic(optional = false)
    @Column(name = "has_children")
    private var hasChildren = false

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Basic(optional = false)
    @Column(name = "parent_id")
    private var parentId: String? = null

    @Column(name = "status")
    private var status: String? = null

    @Column(name = "target_window")
    private var targetWindow: String? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, dfpId: String?, hasChildren: Boolean, name: String?, parentId: String?) {
        this.id = id
        this.version = version
        this.dfpId = dfpId
        this.hasChildren = hasChildren
        this.name = name
        this.parentId = parentId
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getDescription(): String? {
        return description
    }

    fun setDescription(description: String?) {
        this.description = description
    }

    fun getDfpId(): String? {
        return dfpId
    }

    fun setDfpId(dfpId: String?) {
        this.dfpId = dfpId
    }

    fun getHasChildren(): Boolean {
        return hasChildren
    }

    fun setHasChildren(hasChildren: Boolean) {
        this.hasChildren = hasChildren
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getParentId(): String? {
        return parentId
    }

    fun setParentId(parentId: String?) {
        this.parentId = parentId
    }

    fun getStatus(): String? {
        return status
    }

    fun setStatus(status: String?) {
        this.status = status
    }

    fun getTargetWindow(): String? {
        return targetWindow
    }

    fun setTargetWindow(targetWindow: String?) {
        this.targetWindow = targetWindow
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is DfpAdUnit) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.DfpAdUnit[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
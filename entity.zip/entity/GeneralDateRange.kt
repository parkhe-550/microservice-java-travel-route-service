/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "general_date_range")
@XmlRootElement
@NamedQueries(NamedQuery(name = "GeneralDateRange.findAll", query = "SELECT g FROM GeneralDateRange g"))
class GeneralDateRange : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var endDate: Date? = null

    @Basic(optional = false)
    @Column(name = "is_active")
    private var isActive = false

    @Basic(optional = false)
    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var startDate: Date? = null

    @OneToMany(mappedBy = "dateRangeId", fetch = FetchType.LAZY)
    private var dateBasedSubscribersAndFixedCostList: List<DateBasedSubscribersAndFixedCost>? = null

    @OneToMany(mappedBy = "dateRangeId", fetch = FetchType.LAZY)
    private var dateBasedDiscountList: List<DateBasedDiscount>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "dateRangeId", fetch = FetchType.LAZY)
    private var dateBasedPricingModelList: List<DateBasedPricingModel>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, endDate: Date?, isActive: Boolean, startDate: Date?) {
        this.id = id
        this.version = version
        this.endDate = endDate
        this.isActive = isActive
        this.startDate = startDate
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getEndDate(): Date? {
        return endDate
    }

    fun setEndDate(endDate: Date?) {
        this.endDate = endDate
    }

    fun getIsActive(): Boolean {
        return isActive
    }

    fun setIsActive(isActive: Boolean) {
        this.isActive = isActive
    }

    fun getStartDate(): Date? {
        return startDate
    }

    fun setStartDate(startDate: Date?) {
        this.startDate = startDate
    }

    @XmlTransient
    fun getDateBasedSubscribersAndFixedCostList(): List<DateBasedSubscribersAndFixedCost>? {
        return dateBasedSubscribersAndFixedCostList
    }

    fun setDateBasedSubscribersAndFixedCostList(dateBasedSubscribersAndFixedCostList: List<DateBasedSubscribersAndFixedCost>?) {
        this.dateBasedSubscribersAndFixedCostList = dateBasedSubscribersAndFixedCostList
    }

    @XmlTransient
    fun getDateBasedDiscountList(): List<DateBasedDiscount>? {
        return dateBasedDiscountList
    }

    fun setDateBasedDiscountList(dateBasedDiscountList: List<DateBasedDiscount>?) {
        this.dateBasedDiscountList = dateBasedDiscountList
    }

    @XmlTransient
    fun getDateBasedPricingModelList(): List<DateBasedPricingModel>? {
        return dateBasedPricingModelList
    }

    fun setDateBasedPricingModelList(dateBasedPricingModelList: List<DateBasedPricingModel>?) {
        this.dateBasedPricingModelList = dateBasedPricingModelList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is GeneralDateRange) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.GeneralDateRange[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "image")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Image.findAll", query = "SELECT i FROM Image i"))
class Image : Serializable {
    private var image: ByteArray?=null

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "file_name")
    private var fileName: String? = null

    @Column(name = "image_type")
    private var imageType: String? = null

    @Basic(optional = false)
    @Column(name = "original")
    private var original = false

    @OneToMany(mappedBy = "lineItemScreenshotId", fetch = FetchType.LAZY)
    private var lineItemList: List<LineItem>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, fileName: String?, original: Boolean) {
        this.id = id
        this.version = version
        this.fileName = fileName
        this.original = original
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getFileName(): String? {
        return fileName
    }

    fun setFileName(fileName: String?) {
        this.fileName = fileName
    }

    fun getImageType(): String? {
        return imageType
    }

    fun setImageType(imageType: String?) {
        this.imageType = imageType
    }

    fun getOriginal(): Boolean {
        return original
    }

    fun setOriginal(original: Boolean) {
        this.original = original
    }

    @XmlTransient
    fun getLineItemList(): List<LineItem>? {
        return lineItemList
    }

    fun setLineItemList(lineItemList: List<LineItem>?) {
        this.lineItemList = lineItemList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Image) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Image[ id=$id ]"
    }



    companion object {
        private const val serialVersionUID = 1L
    }
}
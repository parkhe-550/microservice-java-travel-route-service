/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "line_item")
@XmlRootElement
@NamedQueries(NamedQuery(name = "LineItem.findAll", query = "SELECT l FROM LineItem l"))
class LineItem : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "agency_discount")
    private var agencyDiscount: BigDecimal? = null

    @Column(name = "customer_discount")
    private var customerDiscount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "end_date_time")
    @Temporal(TemporalType.TIMESTAMP)
    private var endDateTime: Date? = null

    @Column(name = "gross_amount")
    private var grossAmount: BigDecimal? = null

    @Column(name = "invoice_number")
    private var invoiceNumber: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "net_amount")
    private var netAmount: BigDecimal? = null

    @Column(name = "order_number")
    private var orderNumber: String? = null

    @Column(name = "product")
    private var product: String? = null

    @Basic(optional = false)
    @Column(name = "start_date_time")
    @Temporal(TemporalType.TIMESTAMP)
    private var startDateTime: Date? = null

    @Column(name = "subject")
    private var subject: String? = null

    @Column(name = "units_delivered")
    private var unitsDelivered: BigInteger? = null

    @Column(name = "units_sold")
    private var unitsSold: BigInteger? = null

    @Column(name = "cpm")
    private var cpm: BigDecimal? = null

    @Column(name = "type")
    private var type: String? = null

    @Column(name = "is_archived")
    private var isArchived: Boolean? = null

    @Column(name = "units_invoiced")
    private var unitsInvoiced: BigInteger? = null

    @Column(name = "fixed_price")
    private var fixedPrice: BigDecimal? = null

    @Column(name = "is_cancelled")
    private var isCancelled: Boolean? = null

    @Column(name = "sales_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var salesDate: Date? = null

    @Column(name = "clicks_delivered")
    private var clicksDelivered: BigInteger? = null

    @Column(name = "creative_id")
    private var creativeId: String? = null

    @Column(name = "is_missing_creatives")
    private var isMissingCreatives: Boolean? = null

    @Column(name = "report")
    private var report: String? = null

    @Column(name = "report_remark")
    private var reportRemark: String? = null

    @Column(name = "report_run_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var reportRunDate: Date? = null

    @Column(name = "status")
    private var status: String? = null

    @Column(name = "is_excluded_from_report")
    private var isExcludedFromReport: Boolean? = null

    @Column(name = "ad_gapid")
    private var adGapid: String? = null

    @Column(name = "auto_extension_days")
    private var autoExtensionDays: Int? = null

    @Column(name = "non_discountable")
    private var nonDiscountable: BigDecimal? = null

    @Column(name = "exclusive_discount")
    private var exclusiveDiscount: BigDecimal? = null

    @JoinTable(
        name = "line_item_daily_rolling_clicks",
        joinColumns = [JoinColumn(name = "line_item_daily_rolling_clicks_id", referencedColumnName = "id")],
        inverseJoinColumns = [JoinColumn(name = "daily_rolling_clicks_id", referencedColumnName = "id")]
    )
    @ManyToMany(fetch = FetchType.LAZY)
    private var dailyRollingClicksList: List<DailyRollingClicks>? = null

    @JoinColumn(name = "line_item_screenshot_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var lineItemScreenshotId: Image? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, endDateTime: Date?, name: String?, startDateTime: Date?) {
        this.id = id
        this.version = version
        this.endDateTime = endDateTime
        this.name = name
        this.startDateTime = startDateTime
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getAgencyDiscount(): BigDecimal? {
        return agencyDiscount
    }

    fun setAgencyDiscount(agencyDiscount: BigDecimal?) {
        this.agencyDiscount = agencyDiscount
    }

    fun getCustomerDiscount(): BigDecimal? {
        return customerDiscount
    }

    fun setCustomerDiscount(customerDiscount: BigDecimal?) {
        this.customerDiscount = customerDiscount
    }

    fun getEndDateTime(): Date? {
        return endDateTime
    }

    fun setEndDateTime(endDateTime: Date?) {
        this.endDateTime = endDateTime
    }

    fun getGrossAmount(): BigDecimal? {
        return grossAmount
    }

    fun setGrossAmount(grossAmount: BigDecimal?) {
        this.grossAmount = grossAmount
    }

    fun getInvoiceNumber(): String? {
        return invoiceNumber
    }

    fun setInvoiceNumber(invoiceNumber: String?) {
        this.invoiceNumber = invoiceNumber
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getNetAmount(): BigDecimal? {
        return netAmount
    }

    fun setNetAmount(netAmount: BigDecimal?) {
        this.netAmount = netAmount
    }

    fun getOrderNumber(): String? {
        return orderNumber
    }

    fun setOrderNumber(orderNumber: String?) {
        this.orderNumber = orderNumber
    }

    fun getProduct(): String? {
        return product
    }

    fun setProduct(product: String?) {
        this.product = product
    }

    fun getStartDateTime(): Date? {
        return startDateTime
    }

    fun setStartDateTime(startDateTime: Date?) {
        this.startDateTime = startDateTime
    }

    fun getSubject(): String? {
        return subject
    }

    fun setSubject(subject: String?) {
        this.subject = subject
    }

    fun getUnitsDelivered(): BigInteger? {
        return unitsDelivered
    }

    fun setUnitsDelivered(unitsDelivered: BigInteger?) {
        this.unitsDelivered = unitsDelivered
    }

    fun getUnitsSold(): BigInteger? {
        return unitsSold
    }

    fun setUnitsSold(unitsSold: BigInteger?) {
        this.unitsSold = unitsSold
    }

    fun getCpm(): BigDecimal? {
        return cpm
    }

    fun setCpm(cpm: BigDecimal?) {
        this.cpm = cpm
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getIsArchived(): Boolean? {
        return isArchived
    }

    fun setIsArchived(isArchived: Boolean?) {
        this.isArchived = isArchived
    }

    fun getUnitsInvoiced(): BigInteger? {
        return unitsInvoiced
    }

    fun setUnitsInvoiced(unitsInvoiced: BigInteger?) {
        this.unitsInvoiced = unitsInvoiced
    }

    fun getFixedPrice(): BigDecimal? {
        return fixedPrice
    }

    fun setFixedPrice(fixedPrice: BigDecimal?) {
        this.fixedPrice = fixedPrice
    }

    fun getIsCancelled(): Boolean? {
        return isCancelled
    }

    fun setIsCancelled(isCancelled: Boolean?) {
        this.isCancelled = isCancelled
    }

    fun getSalesDate(): Date? {
        return salesDate
    }

    fun setSalesDate(salesDate: Date?) {
        this.salesDate = salesDate
    }

    fun getClicksDelivered(): BigInteger? {
        return clicksDelivered
    }

    fun setClicksDelivered(clicksDelivered: BigInteger?) {
        this.clicksDelivered = clicksDelivered
    }

    fun getCreativeId(): String? {
        return creativeId
    }

    fun setCreativeId(creativeId: String?) {
        this.creativeId = creativeId
    }

    fun getIsMissingCreatives(): Boolean? {
        return isMissingCreatives
    }

    fun setIsMissingCreatives(isMissingCreatives: Boolean?) {
        this.isMissingCreatives = isMissingCreatives
    }

    fun getReport(): String? {
        return report
    }

    fun setReport(report: String?) {
        this.report = report
    }

    fun getReportRemark(): String? {
        return reportRemark
    }

    fun setReportRemark(reportRemark: String?) {
        this.reportRemark = reportRemark
    }

    fun getReportRunDate(): Date? {
        return reportRunDate
    }

    fun setReportRunDate(reportRunDate: Date?) {
        this.reportRunDate = reportRunDate
    }

    fun getStatus(): String? {
        return status
    }

    fun setStatus(status: String?) {
        this.status = status
    }

    fun getIsExcludedFromReport(): Boolean? {
        return isExcludedFromReport
    }

    fun setIsExcludedFromReport(isExcludedFromReport: Boolean?) {
        this.isExcludedFromReport = isExcludedFromReport
    }

    fun getAdGapid(): String? {
        return adGapid
    }

    fun setAdGapid(adGapid: String?) {
        this.adGapid = adGapid
    }

    fun getAutoExtensionDays(): Int? {
        return autoExtensionDays
    }

    fun setAutoExtensionDays(autoExtensionDays: Int?) {
        this.autoExtensionDays = autoExtensionDays
    }

    fun getNonDiscountable(): BigDecimal? {
        return nonDiscountable
    }

    fun setNonDiscountable(nonDiscountable: BigDecimal?) {
        this.nonDiscountable = nonDiscountable
    }

    fun getExclusiveDiscount(): BigDecimal? {
        return exclusiveDiscount
    }

    fun setExclusiveDiscount(exclusiveDiscount: BigDecimal?) {
        this.exclusiveDiscount = exclusiveDiscount
    }

    @XmlTransient
    fun getDailyRollingClicksList(): List<DailyRollingClicks>? {
        return dailyRollingClicksList
    }

    fun setDailyRollingClicksList(dailyRollingClicksList: List<DailyRollingClicks>?) {
        this.dailyRollingClicksList = dailyRollingClicksList
    }

    fun getLineItemScreenshotId(): Image? {
        return lineItemScreenshotId
    }

    fun setLineItemScreenshotId(lineItemScreenshotId: Image?) {
        this.lineItemScreenshotId = lineItemScreenshotId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is LineItem) {
            return false
        }
        val other = `object`
        return if ((id == null && other.id != null || id != null) && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.LineItem[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
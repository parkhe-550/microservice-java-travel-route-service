/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "line_item_statistics")
@XmlRootElement
@NamedQueries(NamedQuery(name = "LineItemStatistics.findAll", query = "SELECT l FROM LineItemStatistics l"))
class LineItemStatistics : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "report_run_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var reportRunDate: Date? = null

    @Column(name = "gross_clicks")
    private var grossClicks: BigInteger? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "gross_ctr")
    private var grossCtr: BigDecimal? = null

    @Column(name = "gross_opening_rate")
    private var grossOpeningRate: BigDecimal? = null

    @Column(name = "gross_openings")
    private var grossOpenings: BigInteger? = null

    @Column(name = "gross_subscribers")
    private var grossSubscribers: BigInteger? = null

    @Column(name = "net_clicks")
    private var netClicks: BigInteger? = null

    @Column(name = "net_ctr")
    private var netCtr: BigDecimal? = null

    @Column(name = "net_opening_rate")
    private var netOpeningRate: BigDecimal? = null

    @Column(name = "net_openings")
    private var netOpenings: BigInteger? = null

    @Column(name = "net_subscribers")
    private var netSubscribers: BigInteger? = null

    @OneToMany(mappedBy = "firstRunStatsId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @OneToMany(mappedBy = "secondRunStatsId", fetch = FetchType.LAZY)
    private var custNewsPriceList1: List<CustNewsPrice>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long) {
        this.id = id
        this.version = version
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getReportRunDate(): Date? {
        return reportRunDate
    }

    fun setReportRunDate(reportRunDate: Date?) {
        this.reportRunDate = reportRunDate
    }

    fun getGrossClicks(): BigInteger? {
        return grossClicks
    }

    fun setGrossClicks(grossClicks: BigInteger?) {
        this.grossClicks = grossClicks
    }

    fun getGrossCtr(): BigDecimal? {
        return grossCtr
    }

    fun setGrossCtr(grossCtr: BigDecimal?) {
        this.grossCtr = grossCtr
    }

    fun getGrossOpeningRate(): BigDecimal? {
        return grossOpeningRate
    }

    fun setGrossOpeningRate(grossOpeningRate: BigDecimal?) {
        this.grossOpeningRate = grossOpeningRate
    }

    fun getGrossOpenings(): BigInteger? {
        return grossOpenings
    }

    fun setGrossOpenings(grossOpenings: BigInteger?) {
        this.grossOpenings = grossOpenings
    }

    fun getGrossSubscribers(): BigInteger? {
        return grossSubscribers
    }

    fun setGrossSubscribers(grossSubscribers: BigInteger?) {
        this.grossSubscribers = grossSubscribers
    }

    fun getNetClicks(): BigInteger? {
        return netClicks
    }

    fun setNetClicks(netClicks: BigInteger?) {
        this.netClicks = netClicks
    }

    fun getNetCtr(): BigDecimal? {
        return netCtr
    }

    fun setNetCtr(netCtr: BigDecimal?) {
        this.netCtr = netCtr
    }

    fun getNetOpeningRate(): BigDecimal? {
        return netOpeningRate
    }

    fun setNetOpeningRate(netOpeningRate: BigDecimal?) {
        this.netOpeningRate = netOpeningRate
    }

    fun getNetOpenings(): BigInteger? {
        return netOpenings
    }

    fun setNetOpenings(netOpenings: BigInteger?) {
        this.netOpenings = netOpenings
    }

    fun getNetSubscribers(): BigInteger? {
        return netSubscribers
    }

    fun setNetSubscribers(netSubscribers: BigInteger?) {
        this.netSubscribers = netSubscribers
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    @XmlTransient
    fun getCustNewsPriceList1(): List<CustNewsPrice>? {
        return custNewsPriceList1
    }

    fun setCustNewsPriceList1(custNewsPriceList1: List<CustNewsPrice>?) {
        this.custNewsPriceList1 = custNewsPriceList1
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is LineItemStatistics) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.LineItemStatistics[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
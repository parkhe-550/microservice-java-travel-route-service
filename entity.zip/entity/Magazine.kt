/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "magazine")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Magazine.findAll", query = "SELECT m FROM Magazine m"))
class Magazine : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "publisher")
    private var publisher: String? = null

    @Column(name = "is_top")
    private var isTop: Boolean? = null

    @Column(name = "is_in_media")
    private var isInMedia: Boolean? = null

    @Column(name = "impression")
    private var impression: String? = null

    @Lob
    @Column(name = "target_group")
    private var targetGroup: String? = null

    @Lob
    @Column(name = "thematic_plan")
    private var thematicPlan: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Lob
    @Column(name = "publication_data")
    private var publicationData: String? = null

    @Lob
    @Column(name = "ranges")
    private var ranges: String? = null

    @Lob
    @Column(name = "unit")
    private var unit: String? = null

    @Column(name = "frequency")
    private var frequency: String? = null

    @Lob
    @Column(name = "ad_formats")
    private var adFormats: String? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, name: String?) {
        this.id = id
        this.version = version
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getPublisher(): String? {
        return publisher
    }

    fun setPublisher(publisher: String?) {
        this.publisher = publisher
    }

    fun getIsTop(): Boolean? {
        return isTop
    }

    fun setIsTop(isTop: Boolean?) {
        this.isTop = isTop
    }

    fun getIsInMedia(): Boolean? {
        return isInMedia
    }

    fun setIsInMedia(isInMedia: Boolean?) {
        this.isInMedia = isInMedia
    }

    fun getImpression(): String? {
        return impression
    }

    fun setImpression(impression: String?) {
        this.impression = impression
    }

    fun getTargetGroup(): String? {
        return targetGroup
    }

    fun setTargetGroup(targetGroup: String?) {
        this.targetGroup = targetGroup
    }

    fun getThematicPlan(): String? {
        return thematicPlan
    }

    fun setThematicPlan(thematicPlan: String?) {
        this.thematicPlan = thematicPlan
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getPublicationData(): String? {
        return publicationData
    }

    fun setPublicationData(publicationData: String?) {
        this.publicationData = publicationData
    }

    fun getRanges(): String? {
        return ranges
    }

    fun setRanges(ranges: String?) {
        this.ranges = ranges
    }

    fun getUnit(): String? {
        return unit
    }

    fun setUnit(unit: String?) {
        this.unit = unit
    }

    fun getFrequency(): String? {
        return frequency
    }

    fun setFrequency(frequency: String?) {
        this.frequency = frequency
    }

    fun getAdFormats(): String? {
        return adFormats
    }

    fun setAdFormats(adFormats: String?) {
        this.adFormats = adFormats
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Magazine) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Magazine[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
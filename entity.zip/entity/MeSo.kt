/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "me_so")
@XmlRootElement
@NamedQueries(NamedQuery(name = "MeSo.findAll", query = "SELECT m FROM MeSo m"))
class MeSo : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "active")
    private var active: Boolean? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "agency_discount")
    private var agencyDiscount: BigDecimal? = null

    @Column(name = "agency_discount_amount")
    private var agencyDiscountAmount: BigDecimal? = null

    @Column(name = "discount")
    private var discount: BigDecimal? = null

    @Column(name = "discount_amount")
    private var discountAmount: BigDecimal? = null

    @Column(name = "gross_amount")
    private var grossAmount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "invoice_number")
    private var invoiceNumber: String? = null

    @Column(name = "invoice_to")
    private var invoiceTo: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "net_amount")
    private var netAmount: BigDecimal? = null

    @Column(name = "order_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var orderDate: Date? = null

    @Basic(optional = false)
    @Column(name = "order_number")
    private var orderNumber: String? = null

    @Column(name = "po_number")
    private var poNumber: String? = null

    @Column(name = "product")
    private var product: String? = null

    @Column(name = "project")
    private var project: String? = null

    @Column(name = "sold_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var soldDate: Date? = null

    @Column(name = "sub_total")
    private var subTotal: BigDecimal? = null

    @Column(name = "subject")
    private var subject: String? = null

    @Column(name = "total_discount_amount")
    private var totalDiscountAmount: BigDecimal? = null

    @JoinColumn(name = "ad_product_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var adProductId: AdProduct? = null

    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var branchId: Branch? = null

    @JoinColumn(name = "business_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var businessId: Business? = null

    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "agency_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var agencyId: Customer? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "salesman_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var salesmanId: User? = null

    @JoinColumn(name = "kam_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var kamId: User? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, invoiceNumber: String?, name: String?, orderNumber: String?) {
        this.id = id
        this.version = version
        this.invoiceNumber = invoiceNumber
        this.name = name
        this.orderNumber = orderNumber
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getActive(): Boolean? {
        return active
    }

    fun setActive(active: Boolean?) {
        this.active = active
    }

    fun getAgencyDiscount(): BigDecimal? {
        return agencyDiscount
    }

    fun setAgencyDiscount(agencyDiscount: BigDecimal?) {
        this.agencyDiscount = agencyDiscount
    }

    fun getAgencyDiscountAmount(): BigDecimal? {
        return agencyDiscountAmount
    }

    fun setAgencyDiscountAmount(agencyDiscountAmount: BigDecimal?) {
        this.agencyDiscountAmount = agencyDiscountAmount
    }

    fun getDiscount(): BigDecimal? {
        return discount
    }

    fun setDiscount(discount: BigDecimal?) {
        this.discount = discount
    }

    fun getDiscountAmount(): BigDecimal? {
        return discountAmount
    }

    fun setDiscountAmount(discountAmount: BigDecimal?) {
        this.discountAmount = discountAmount
    }

    fun getGrossAmount(): BigDecimal? {
        return grossAmount
    }

    fun setGrossAmount(grossAmount: BigDecimal?) {
        this.grossAmount = grossAmount
    }

    fun getInvoiceNumber(): String? {
        return invoiceNumber
    }

    fun setInvoiceNumber(invoiceNumber: String?) {
        this.invoiceNumber = invoiceNumber
    }

    fun getInvoiceTo(): String? {
        return invoiceTo
    }

    fun setInvoiceTo(invoiceTo: String?) {
        this.invoiceTo = invoiceTo
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getNetAmount(): BigDecimal? {
        return netAmount
    }

    fun setNetAmount(netAmount: BigDecimal?) {
        this.netAmount = netAmount
    }

    fun getOrderDate(): Date? {
        return orderDate
    }

    fun setOrderDate(orderDate: Date?) {
        this.orderDate = orderDate
    }

    fun getOrderNumber(): String? {
        return orderNumber
    }

    fun setOrderNumber(orderNumber: String?) {
        this.orderNumber = orderNumber
    }

    fun getPoNumber(): String? {
        return poNumber
    }

    fun setPoNumber(poNumber: String?) {
        this.poNumber = poNumber
    }

    fun getProduct(): String? {
        return product
    }

    fun setProduct(product: String?) {
        this.product = product
    }

    fun getProject(): String? {
        return project
    }

    fun setProject(project: String?) {
        this.project = project
    }

    fun getSoldDate(): Date? {
        return soldDate
    }

    fun setSoldDate(soldDate: Date?) {
        this.soldDate = soldDate
    }

    fun getSubTotal(): BigDecimal? {
        return subTotal
    }

    fun setSubTotal(subTotal: BigDecimal?) {
        this.subTotal = subTotal
    }

    fun getSubject(): String? {
        return subject
    }

    fun setSubject(subject: String?) {
        this.subject = subject
    }

    fun getTotalDiscountAmount(): BigDecimal? {
        return totalDiscountAmount
    }

    fun setTotalDiscountAmount(totalDiscountAmount: BigDecimal?) {
        this.totalDiscountAmount = totalDiscountAmount
    }

    fun getAdProductId(): AdProduct? {
        return adProductId
    }

    fun setAdProductId(adProductId: AdProduct?) {
        this.adProductId = adProductId
    }

    fun getBranchId(): Branch? {
        return branchId
    }

    fun setBranchId(branchId: Branch?) {
        this.branchId = branchId
    }

    fun getBusinessId(): Business? {
        return businessId
    }

    fun setBusinessId(businessId: Business?) {
        this.businessId = businessId
    }

    fun getCustomerId(): Customer? {
        return customerId
    }

    fun setCustomerId(customerId: Customer?) {
        this.customerId = customerId
    }

    fun getAgencyId(): Customer? {
        return agencyId
    }

    fun setAgencyId(agencyId: Customer?) {
        this.agencyId = agencyId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getSalesmanId(): User? {
        return salesmanId
    }

    fun setSalesmanId(salesmanId: User?) {
        this.salesmanId = salesmanId
    }

    fun getKamId(): User? {
        return kamId
    }

    fun setKamId(kamId: User?) {
        this.kamId = kamId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is MeSo) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.MeSo[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
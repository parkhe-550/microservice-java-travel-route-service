/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "media_suite_ad_product")
@XmlRootElement
@NamedQueries(NamedQuery(name = "MediaSuiteAdProduct.findAll", query = "SELECT m FROM MediaSuiteAdProduct m"))
class MediaSuiteAdProduct : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "nsales_item_id")
    private var nsalesItemId: String? = null

    @Column(name = "comment")
    private var comment: String? = null

    @Basic(optional = false)
    @Column(name = "is_active")
    private var isActive = false

    @Basic(optional = false)
    @Column(name = "media_suite_object_id")
    private var mediaSuiteObjectId: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Basic(optional = false)
    @Column(name = "rate_card_id")
    private var rateCardId: String? = null

    @Basic(optional = false)
    @Column(name = "type")
    private var type: String? = null

    @Basic(optional = false)
    @Column(name = "n_sales_item_id")
    private var nSalesItemId: String? = null

    @JoinColumn(name = "ad_product_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adProductId: AdProduct? = null

    @JoinColumn(name = "product_type_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var productTypeId: Carrier? = null

    @JoinColumn(name = "object_info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var objectInfoId: ObjectInfo? = null

    //    @JoinColumn(name = "product_type_id", referencedColumnName = "id")
    //    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var productTypeId1: ProductType? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        nsalesItemId: String?,
        isActive: Boolean,
        mediaSuiteObjectId: String?,
        name: String?,
        rateCardId: String?,
        type: String?,
        nSalesItemId: String?
    ) {
        this.id = id
        this.version = version
        this.nsalesItemId = nsalesItemId
        this.isActive = isActive
        this.mediaSuiteObjectId = mediaSuiteObjectId
        this.name = name
        this.rateCardId = rateCardId
        this.type = type
        this.nSalesItemId = nSalesItemId
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getNsalesItemId(): String? {
        return nsalesItemId
    }

    fun setNsalesItemId(nsalesItemId: String?) {
        this.nsalesItemId = nsalesItemId
    }

    fun getComment(): String? {
        return comment
    }

    fun setComment(comment: String?) {
        this.comment = comment
    }

    fun getIsActive(): Boolean {
        return isActive
    }

    fun setIsActive(isActive: Boolean) {
        this.isActive = isActive
    }

    fun getMediaSuiteObjectId(): String? {
        return mediaSuiteObjectId
    }

    fun setMediaSuiteObjectId(mediaSuiteObjectId: String?) {
        this.mediaSuiteObjectId = mediaSuiteObjectId
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getRateCardId(): String? {
        return rateCardId
    }

    fun setRateCardId(rateCardId: String?) {
        this.rateCardId = rateCardId
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getNSalesItemId(): String? {
        return nSalesItemId
    }

    fun setNSalesItemId(nSalesItemId: String?) {
        this.nSalesItemId = nSalesItemId
    }

    fun getAdProductId(): AdProduct? {
        return adProductId
    }

    fun setAdProductId(adProductId: AdProduct?) {
        this.adProductId = adProductId
    }

    fun getProductTypeId(): Carrier? {
        return productTypeId
    }

    fun setProductTypeId(productTypeId: Carrier?) {
        this.productTypeId = productTypeId
    }

    fun getObjectInfoId(): ObjectInfo? {
        return objectInfoId
    }

    fun setObjectInfoId(objectInfoId: ObjectInfo?) {
        this.objectInfoId = objectInfoId
    }

    fun getProductTypeId1(): ProductType? {
        return productTypeId1
    }

    fun setProductTypeId1(productTypeId1: ProductType?) {
        this.productTypeId1 = productTypeId1
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is MediaSuiteAdProduct) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.MediaSuiteAdProduct[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
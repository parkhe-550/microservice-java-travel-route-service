/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "my_newsletter_offer")
@XmlRootElement
@NamedQueries(NamedQuery(name = "MyNewsletterOffer.findAll", query = "SELECT m FROM MyNewsletterOffer m"))
class MyNewsletterOffer : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "active")
    private var active = false

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "offer_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var offerDate: Date? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "agency_discount")
    private var agencyDiscount: Double? = null

    @Column(name = "discount")
    private var discount: Double? = null

    @OneToMany(mappedBy = "offerId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var userId: User? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, active: Boolean, name: String?) {
        this.id = id
        this.version = version
        this.active = active
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getActive(): Boolean {
        return active
    }

    fun setActive(active: Boolean) {
        this.active = active
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getOfferDate(): Date? {
        return offerDate
    }

    fun setOfferDate(offerDate: Date?) {
        this.offerDate = offerDate
    }

    fun getAgencyDiscount(): Double? {
        return agencyDiscount
    }

    fun setAgencyDiscount(agencyDiscount: Double?) {
        this.agencyDiscount = agencyDiscount
    }

    fun getDiscount(): Double? {
        return discount
    }

    fun setDiscount(discount: Double?) {
        this.discount = discount
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getUserId(): User? {
        return userId
    }

    fun setUserId(userId: User?) {
        this.userId = userId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is MyNewsletterOffer) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.MyNewsletterOffer[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
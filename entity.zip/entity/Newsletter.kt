/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "newsletter")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Newsletter.findAll", query = "SELECT n FROM Newsletter n"))
class Newsletter : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "subscription")
    private var subscription: BigInteger? = null

    @Column(name = "is_in_media")
    private var isInMedia: Boolean? = null

    @Column(name = "media_name")
    private var mediaName: String? = null

    @Column(name = "count_limit")
    private var countLimit: Int? = null

    @Column(name = "ecircle")
    private var ecircle: Boolean? = null

    @Column(name = "ecircle_template")
    private var ecircleTemplate: String? = null

    @Column(name = "area")
    private var area: String? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "fixed_price")
    private var fixedPrice: BigDecimal? = null

    @Column(name = "invoice_name")
    private var invoiceName: String? = null

    @Column(name = "marketing_ad_slots")
    private var marketingAdSlots: Int? = null

    @ManyToMany(mappedBy = "newsletterList", fetch = FetchType.LAZY)
    private var topicList: List<Topic>? = null

    @JoinColumn(name = "group_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var groupId: BusinessGroup? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "website_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var websiteId: Website? = null

    @JoinColumn(name = "recommended_frequence_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var recommendedFrequenceId: ZeitPlaner? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "newsletterId", fetch = FetchType.LAZY)
    private var newsletterSendList: List<NewsletterSend>? = null

    @OneToMany(mappedBy = "newsletterId", fetch = FetchType.LAZY)
    private var thirdPartyList: List<ThirdParty>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, name: String?) {
        this.id = id
        this.version = version
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getSubscription(): BigInteger? {
        return subscription
    }

    fun setSubscription(subscription: BigInteger?) {
        this.subscription = subscription
    }

    fun getIsInMedia(): Boolean? {
        return isInMedia
    }

    fun setIsInMedia(isInMedia: Boolean?) {
        this.isInMedia = isInMedia
    }

    fun getMediaName(): String? {
        return mediaName
    }

    fun setMediaName(mediaName: String?) {
        this.mediaName = mediaName
    }

    fun getCountLimit(): Int? {
        return countLimit
    }

    fun setCountLimit(countLimit: Int?) {
        this.countLimit = countLimit
    }

    fun getEcircle(): Boolean? {
        return ecircle
    }

    fun setEcircle(ecircle: Boolean?) {
        this.ecircle = ecircle
    }

    fun getEcircleTemplate(): String? {
        return ecircleTemplate
    }

    fun setEcircleTemplate(ecircleTemplate: String?) {
        this.ecircleTemplate = ecircleTemplate
    }

    fun getArea(): String? {
        return area
    }

    fun setArea(area: String?) {
        this.area = area
    }

    fun getFixedPrice(): BigDecimal? {
        return fixedPrice
    }

    fun setFixedPrice(fixedPrice: BigDecimal?) {
        this.fixedPrice = fixedPrice
    }

    fun getInvoiceName(): String? {
        return invoiceName
    }

    fun setInvoiceName(invoiceName: String?) {
        this.invoiceName = invoiceName
    }

    fun getMarketingAdSlots(): Int? {
        return marketingAdSlots
    }

    fun setMarketingAdSlots(marketingAdSlots: Int?) {
        this.marketingAdSlots = marketingAdSlots
    }

    @XmlTransient
    fun getTopicList(): List<Topic>? {
        return topicList
    }

    fun setTopicList(topicList: List<Topic>?) {
        this.topicList = topicList
    }

    fun getGroupId(): BusinessGroup? {
        return groupId
    }

    fun setGroupId(groupId: BusinessGroup?) {
        this.groupId = groupId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getWebsiteId(): Website? {
        return websiteId
    }

    fun setWebsiteId(websiteId: Website?) {
        this.websiteId = websiteId
    }

    fun getRecommendedFrequenceId(): ZeitPlaner? {
        return recommendedFrequenceId
    }

    fun setRecommendedFrequenceId(recommendedFrequenceId: ZeitPlaner?) {
        this.recommendedFrequenceId = recommendedFrequenceId
    }

    @XmlTransient
    fun getNewsletterSendList(): List<NewsletterSend>? {
        return newsletterSendList
    }

    fun setNewsletterSendList(newsletterSendList: List<NewsletterSend>?) {
        this.newsletterSendList = newsletterSendList
    }

    @XmlTransient
    fun getThirdPartyList(): List<ThirdParty>? {
        return thirdPartyList
    }

    fun setThirdPartyList(thirdPartyList: List<ThirdParty>?) {
        this.thirdPartyList = thirdPartyList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Newsletter) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Newsletter[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.math.BigInteger
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "newsletter_offer")
@XmlRootElement
@NamedQueries(NamedQuery(name = "NewsletterOffer.findAll", query = "SELECT n FROM NewsletterOffer n"))
class NewsletterOffer : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "active")
    private var active = false

    @Basic(optional = false)
    @Column(name = "agency_discount")
    private var agencyDiscount = 0.0

    @Basic(optional = false)
    @Column(name = "discount")
    private var discount = 0.0

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Column(name = "status_id")
    private var statusId: BigInteger? = null

    @Basic(optional = false)
    @Column(name = "total_price")
    private var totalPrice = 0.0

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "sold_price")
    private var soldPrice: Double? = null

    @Column(name = "invoice_to")
    private var invoiceTo: String? = null

    @Column(name = "po_number")
    private var poNumber: String? = null

    @Column(name = "product")
    private var product: String? = null

    @Column(name = "subject")
    private var subject: String? = null

    @Column(name = "is_archived")
    private var isArchived: Boolean? = null

    @Column(name = "is_cancelled")
    private var isCancelled: Boolean? = null

    @Column(name = "campaign_period")
    private var campaignPeriod: String? = null

    @Column(name = "concept")
    private var concept: BigDecimal? = null

    @Column(name = "content")
    private var content: BigDecimal? = null

    @Column(name = "diverse")
    private var diverse: BigDecimal? = null

    @Column(name = "gross_clicks")
    private var grossClicks: BigInteger? = null

    @Column(name = "gross_ctr")
    private var grossCtr: BigDecimal? = null

    @Column(name = "gross_opening_rate")
    private var grossOpeningRate: BigDecimal? = null

    @Column(name = "gross_openings")
    private var grossOpenings: BigInteger? = null

    @Column(name = "gross_subscribers")
    private var grossSubscribers: BigInteger? = null

    @Column(name = "net_clicks")
    private var netClicks: BigInteger? = null

    @Column(name = "net_ctr")
    private var netCtr: BigDecimal? = null

    @Column(name = "net_opening_rate")
    private var netOpeningRate: BigDecimal? = null

    @Column(name = "net_openings")
    private var netOpenings: BigInteger? = null

    @Column(name = "net_subscribers")
    private var netSubscribers: BigInteger? = null

    @Column(name = "report")
    private var report: String? = null

    @Column(name = "report_remark")
    private var reportRemark: String? = null

    @Column(name = "type")
    private var type: String? = null

    @Column(name = "exclusive_discount")
    private var exclusiveDiscount: Double? = null

    @Column(name = "bundle_type")
    private var bundleType: String? = null

    @Column(name = "campaign_version")
    private var campaignVersion: Int? = null

    @Lob
    @Column(name = "notes")
    private var notes: String? = null

    @JoinColumn(name = "bundle_campaign_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var bundleCampaignId: BundleCampaign? = null

    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customerId: Customer? = null

    @JoinColumn(name = "agency_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var agencyId: Customer? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "salesman_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var salesmanId: User? = null

    @JoinColumn(name = "ad_ops_user_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adOpsUserId: User? = null

    @JoinColumn(name = "useradw_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var useradwId: Useradw? = null

    @OneToMany(mappedBy = "newsletterOfferId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        active: Boolean,
        agencyDiscount: Double,
        discount: Double,
        name: String?,
        totalPrice: Double
    ) {
        this.id = id
        this.version = version
        this.active = active
        this.agencyDiscount = agencyDiscount
        this.discount = discount
        this.name = name
        this.totalPrice = totalPrice
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getActive(): Boolean {
        return active
    }

    fun setActive(active: Boolean) {
        this.active = active
    }

    fun getAgencyDiscount(): Double {
        return agencyDiscount
    }

    fun setAgencyDiscount(agencyDiscount: Double) {
        this.agencyDiscount = agencyDiscount
    }

    fun getDiscount(): Double {
        return discount
    }

    fun setDiscount(discount: Double) {
        this.discount = discount
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getStatusId(): BigInteger? {
        return statusId
    }

    fun setStatusId(statusId: BigInteger?) {
        this.statusId = statusId
    }

    fun getTotalPrice(): Double {
        return totalPrice
    }

    fun setTotalPrice(totalPrice: Double) {
        this.totalPrice = totalPrice
    }

    fun getSoldPrice(): Double? {
        return soldPrice
    }

    fun setSoldPrice(soldPrice: Double?) {
        this.soldPrice = soldPrice
    }

    fun getInvoiceTo(): String? {
        return invoiceTo
    }

    fun setInvoiceTo(invoiceTo: String?) {
        this.invoiceTo = invoiceTo
    }

    fun getPoNumber(): String? {
        return poNumber
    }

    fun setPoNumber(poNumber: String?) {
        this.poNumber = poNumber
    }

    fun getProduct(): String? {
        return product
    }

    fun setProduct(product: String?) {
        this.product = product
    }

    fun getSubject(): String? {
        return subject
    }

    fun setSubject(subject: String?) {
        this.subject = subject
    }

    fun getIsArchived(): Boolean? {
        return isArchived
    }

    fun setIsArchived(isArchived: Boolean?) {
        this.isArchived = isArchived
    }

    fun getIsCancelled(): Boolean? {
        return isCancelled
    }

    fun setIsCancelled(isCancelled: Boolean?) {
        this.isCancelled = isCancelled
    }

    fun getCampaignPeriod(): String? {
        return campaignPeriod
    }

    fun setCampaignPeriod(campaignPeriod: String?) {
        this.campaignPeriod = campaignPeriod
    }

    fun getConcept(): BigDecimal? {
        return concept
    }

    fun setConcept(concept: BigDecimal?) {
        this.concept = concept
    }

    fun getContent(): BigDecimal? {
        return content
    }

    fun setContent(content: BigDecimal?) {
        this.content = content
    }

    fun getDiverse(): BigDecimal? {
        return diverse
    }

    fun setDiverse(diverse: BigDecimal?) {
        this.diverse = diverse
    }

    fun getGrossClicks(): BigInteger? {
        return grossClicks
    }

    fun setGrossClicks(grossClicks: BigInteger?) {
        this.grossClicks = grossClicks
    }

    fun getGrossCtr(): BigDecimal? {
        return grossCtr
    }

    fun setGrossCtr(grossCtr: BigDecimal?) {
        this.grossCtr = grossCtr
    }

    fun getGrossOpeningRate(): BigDecimal? {
        return grossOpeningRate
    }

    fun setGrossOpeningRate(grossOpeningRate: BigDecimal?) {
        this.grossOpeningRate = grossOpeningRate
    }

    fun getGrossOpenings(): BigInteger? {
        return grossOpenings
    }

    fun setGrossOpenings(grossOpenings: BigInteger?) {
        this.grossOpenings = grossOpenings
    }

    fun getGrossSubscribers(): BigInteger? {
        return grossSubscribers
    }

    fun setGrossSubscribers(grossSubscribers: BigInteger?) {
        this.grossSubscribers = grossSubscribers
    }

    fun getNetClicks(): BigInteger? {
        return netClicks
    }

    fun setNetClicks(netClicks: BigInteger?) {
        this.netClicks = netClicks
    }

    fun getNetCtr(): BigDecimal? {
        return netCtr
    }

    fun setNetCtr(netCtr: BigDecimal?) {
        this.netCtr = netCtr
    }

    fun getNetOpeningRate(): BigDecimal? {
        return netOpeningRate
    }

    fun setNetOpeningRate(netOpeningRate: BigDecimal?) {
        this.netOpeningRate = netOpeningRate
    }

    fun getNetOpenings(): BigInteger? {
        return netOpenings
    }

    fun setNetOpenings(netOpenings: BigInteger?) {
        this.netOpenings = netOpenings
    }

    fun getNetSubscribers(): BigInteger? {
        return netSubscribers
    }

    fun setNetSubscribers(netSubscribers: BigInteger?) {
        this.netSubscribers = netSubscribers
    }

    fun getReport(): String? {
        return report
    }

    fun setReport(report: String?) {
        this.report = report
    }

    fun getReportRemark(): String? {
        return reportRemark
    }

    fun setReportRemark(reportRemark: String?) {
        this.reportRemark = reportRemark
    }

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getExclusiveDiscount(): Double? {
        return exclusiveDiscount
    }

    fun setExclusiveDiscount(exclusiveDiscount: Double?) {
        this.exclusiveDiscount = exclusiveDiscount
    }

    fun getBundleType(): String? {
        return bundleType
    }

    fun setBundleType(bundleType: String?) {
        this.bundleType = bundleType
    }

    fun getCampaignVersion(): Int? {
        return campaignVersion
    }

    fun setCampaignVersion(campaignVersion: Int?) {
        this.campaignVersion = campaignVersion
    }

    fun getNotes(): String? {
        return notes
    }

    fun setNotes(notes: String?) {
        this.notes = notes
    }

    fun getBundleCampaignId(): BundleCampaign? {
        return bundleCampaignId
    }

    fun setBundleCampaignId(bundleCampaignId: BundleCampaign?) {
        this.bundleCampaignId = bundleCampaignId
    }

    fun getCustomerId(): Customer? {
        return customerId
    }

    fun setCustomerId(customerId: Customer?) {
        this.customerId = customerId
    }

    fun getAgencyId(): Customer? {
        return agencyId
    }

    fun setAgencyId(agencyId: Customer?) {
        this.agencyId = agencyId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getSalesmanId(): User? {
        return salesmanId
    }

    fun setSalesmanId(salesmanId: User?) {
        this.salesmanId = salesmanId
    }

    fun getAdOpsUserId(): User? {
        return adOpsUserId
    }

    fun setAdOpsUserId(adOpsUserId: User?) {
        this.adOpsUserId = adOpsUserId
    }

    fun getUseradwId(): Useradw? {
        return useradwId
    }

    fun setUseradwId(useradwId: Useradw?) {
        this.useradwId = useradwId
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is NewsletterOffer) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.NewsletterOffer[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
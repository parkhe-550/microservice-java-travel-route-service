/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "newsletter_status")
@XmlRootElement
@NamedQueries(NamedQuery(name = "NewsletterStatus.findAll", query = "SELECT n FROM NewsletterStatus n"))
class NewsletterStatus : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "label")
    private var label: String? = null

    @Basic(optional = false)
    @Column(name = "value")
    private var value: String? = null

    @OneToMany(mappedBy = "statusId", fetch = FetchType.LAZY)
    private var newsletterSendList: List<NewsletterSend>? = null

    @OneToMany(mappedBy = "marketingAdStatusId", fetch = FetchType.LAZY)
    private var newsletterSendList1: List<NewsletterSend>? = null

    @OneToMany(mappedBy = "statusId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, label: String?, value: String?) {
        this.id = id
        this.version = version
        this.label = label
        this.value = value
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getLabel(): String? {
        return label
    }

    fun setLabel(label: String?) {
        this.label = label
    }

    fun getValue(): String? {
        return value
    }

    fun setValue(value: String?) {
        this.value = value
    }

    @XmlTransient
    fun getNewsletterSendList(): List<NewsletterSend>? {
        return newsletterSendList
    }

    fun setNewsletterSendList(newsletterSendList: List<NewsletterSend>?) {
        this.newsletterSendList = newsletterSendList
    }

    @XmlTransient
    fun getNewsletterSendList1(): List<NewsletterSend>? {
        return newsletterSendList1
    }

    fun setNewsletterSendList1(newsletterSendList1: List<NewsletterSend>?) {
        this.newsletterSendList1 = newsletterSendList1
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is NewsletterStatus) {
            return false
        }
        val other = `object`
        return if ((id == null && other.id != null || id != null) && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.NewsletterStatus[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
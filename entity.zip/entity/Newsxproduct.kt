/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "newsxproduct")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Newsxproduct.findAll", query = "SELECT n FROM Newsxproduct n"))
class Newsxproduct : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "recommended_price")
    private var recommendedPrice: BigDecimal? = null

    @JoinColumn(name = "product_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var productId: AdProduct? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, recommendedPrice: BigDecimal?) {
        this.id = id
        this.version = version
        this.recommendedPrice = recommendedPrice
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getRecommendedPrice(): BigDecimal? {
        return recommendedPrice
    }

    fun setRecommendedPrice(recommendedPrice: BigDecimal?) {
        this.recommendedPrice = recommendedPrice
    }

    fun getProductId(): AdProduct? {
        return productId
    }

    fun setProductId(productId: AdProduct?) {
        this.productId = productId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Newsxproduct) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Newsxproduct[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigInteger
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "object_info")
@XmlRootElement
@NamedQueries(NamedQuery(name = "ObjectInfo.findAll", query = "SELECT o FROM ObjectInfo o"))
class ObjectInfo : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "comment")
    private var comment: String? = null

    @Lob
    @Column(name = "dart_comment")
    private var dartComment: String? = null

    @Basic(optional = false)
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private var dateCreated: Date? = null

    @Column(name = "date_import")
    @Temporal(TemporalType.TIMESTAMP)
    private var dateImport: Date? = null

    @Basic(optional = false)
    @Column(name = "date_modification")
    @Temporal(TemporalType.TIMESTAMP)
    private var dateModification: Date? = null

    @Column(name = "external_id")
    private var externalId: String? = null

    @Column(name = "media_suite_id")
    private var mediaSuiteId: String? = null

    @Column(name = "media_suite_name")
    private var mediaSuiteName: String? = null

    @Column(name = "ms_export_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var msExportDate: Date? = null

    @Column(name = "ms_import_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var msImportDate: Date? = null

    @Column(name = "extra_field_id")
    private var extraFieldId: BigInteger? = null

    @Column(name = "extra_field_one")
    private var extraFieldOne: String? = null

    @Lob
    @Column(name = "extra_field_remark")
    private var extraFieldRemark: String? = null

    @Column(name = "extra_field_two")
    private var extraFieldTwo: String? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var countryList: List<Country>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var newsletterList: List<Newsletter>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var newsletterSendList: List<NewsletterSend>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var otherProductsList: List<OtherProducts>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var fileResourceRefList: List<FileResourceRef>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var officeList: List<Office>? = null

    @OneToMany(mappedBy = "objectInfoId", fetch = FetchType.LAZY)
    private var mediaSuiteAdProductList: List<MediaSuiteAdProduct>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var branchList: List<Branch>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var devisionList: List<Devision>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var lineItemList: List<LineItem>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var pricingModelList: List<PricingModel>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var adList: List<Ad>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var customFieldOptionList: List<CustomFieldOption>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var useradwList: List<Useradw>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var newsletterOfferList: List<NewsletterOffer>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var campaignList: List<Campaign>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var topicList: List<Topic>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var placementList: List<Placement>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var thirdPartyList: List<ThirdParty>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var dfpCustomFieldList: List<DfpCustomField>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var meSoList: List<MeSo>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var targetGroupList: List<TargetGroup>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var zeitPlanerList: List<ZeitPlaner>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var customFieldList: List<CustomField>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var websiteList: List<Website>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var businessList: List<Business>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var newsletterServiceChargeList: List<NewsletterServiceCharge>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var adUnitList: List<AdUnit>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var carrierList: List<Carrier>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var productTypeList: List<ProductType>? = null

    @JoinColumn(name = "custom_field_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customFieldId: CustomField? = null

    @JoinColumn(name = "custom_field_option_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var customFieldOptionId: CustomFieldOption? = null

    @JoinColumn(name = "modifier_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var modifierId: User? = null

    @JoinColumn(name = "creator_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var creatorId: User? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var reportList: List<Report>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var magazineList: List<Magazine>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var userList: List<User>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "infoId", fetch = FetchType.LAZY)
    private var myNewsletterOfferList: List<MyNewsletterOffer>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var adProductList: List<AdProduct>? = null

    @OneToMany(mappedBy = "infoId", fetch = FetchType.LAZY)
    private var customerList: List<Customer>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, dateCreated: Date?, dateModification: Date?) {
        this.id = id
        this.version = version
        this.dateCreated = dateCreated
        this.dateModification = dateModification
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getComment(): String? {
        return comment
    }

    fun setComment(comment: String?) {
        this.comment = comment
    }

    fun getDartComment(): String? {
        return dartComment
    }

    fun setDartComment(dartComment: String?) {
        this.dartComment = dartComment
    }

    fun getDateCreated(): Date? {
        return dateCreated
    }

    fun setDateCreated(dateCreated: Date?) {
        this.dateCreated = dateCreated
    }

    fun getDateImport(): Date? {
        return dateImport
    }

    fun setDateImport(dateImport: Date?) {
        this.dateImport = dateImport
    }

    fun getDateModification(): Date? {
        return dateModification
    }

    fun setDateModification(dateModification: Date?) {
        this.dateModification = dateModification
    }

    fun getExternalId(): String? {
        return externalId
    }

    fun setExternalId(externalId: String?) {
        this.externalId = externalId
    }

    fun getMediaSuiteId(): String? {
        return mediaSuiteId
    }

    fun setMediaSuiteId(mediaSuiteId: String?) {
        this.mediaSuiteId = mediaSuiteId
    }

    fun getMediaSuiteName(): String? {
        return mediaSuiteName
    }

    fun setMediaSuiteName(mediaSuiteName: String?) {
        this.mediaSuiteName = mediaSuiteName
    }

    fun getMsExportDate(): Date? {
        return msExportDate
    }

    fun setMsExportDate(msExportDate: Date?) {
        this.msExportDate = msExportDate
    }

    fun getMsImportDate(): Date? {
        return msImportDate
    }

    fun setMsImportDate(msImportDate: Date?) {
        this.msImportDate = msImportDate
    }

    fun getExtraFieldId(): BigInteger? {
        return extraFieldId
    }

    fun setExtraFieldId(extraFieldId: BigInteger?) {
        this.extraFieldId = extraFieldId
    }

    fun getExtraFieldOne(): String? {
        return extraFieldOne
    }

    fun setExtraFieldOne(extraFieldOne: String?) {
        this.extraFieldOne = extraFieldOne
    }

    fun getExtraFieldRemark(): String? {
        return extraFieldRemark
    }

    fun setExtraFieldRemark(extraFieldRemark: String?) {
        this.extraFieldRemark = extraFieldRemark
    }

    fun getExtraFieldTwo(): String? {
        return extraFieldTwo
    }

    fun setExtraFieldTwo(extraFieldTwo: String?) {
        this.extraFieldTwo = extraFieldTwo
    }

    @XmlTransient
    fun getCountryList(): List<Country>? {
        return countryList
    }

    fun setCountryList(countryList: List<Country>?) {
        this.countryList = countryList
    }

    @XmlTransient
    fun getNewsletterList(): List<Newsletter>? {
        return newsletterList
    }

    fun setNewsletterList(newsletterList: List<Newsletter>?) {
        this.newsletterList = newsletterList
    }

    @XmlTransient
    fun getNewsletterSendList(): List<NewsletterSend>? {
        return newsletterSendList
    }

    fun setNewsletterSendList(newsletterSendList: List<NewsletterSend>?) {
        this.newsletterSendList = newsletterSendList
    }

    @XmlTransient
    fun getOtherProductsList(): List<OtherProducts>? {
        return otherProductsList
    }

    fun setOtherProductsList(otherProductsList: List<OtherProducts>?) {
        this.otherProductsList = otherProductsList
    }

    @XmlTransient
    fun getFileResourceRefList(): List<FileResourceRef>? {
        return fileResourceRefList
    }

    fun setFileResourceRefList(fileResourceRefList: List<FileResourceRef>?) {
        this.fileResourceRefList = fileResourceRefList
    }

    @XmlTransient
    fun getOfficeList(): List<Office>? {
        return officeList
    }

    fun setOfficeList(officeList: List<Office>?) {
        this.officeList = officeList
    }

    @XmlTransient
    fun getMediaSuiteAdProductList(): List<MediaSuiteAdProduct>? {
        return mediaSuiteAdProductList
    }

    fun setMediaSuiteAdProductList(mediaSuiteAdProductList: List<MediaSuiteAdProduct>?) {
        this.mediaSuiteAdProductList = mediaSuiteAdProductList
    }

    @XmlTransient
    fun getBranchList(): List<Branch>? {
        return branchList
    }

    fun setBranchList(branchList: List<Branch>?) {
        this.branchList = branchList
    }

    @XmlTransient
    fun getDevisionList(): List<Devision>? {
        return devisionList
    }

    fun setDevisionList(devisionList: List<Devision>?) {
        this.devisionList = devisionList
    }

    @XmlTransient
    fun getLineItemList(): List<LineItem>? {
        return lineItemList
    }

    fun setLineItemList(lineItemList: List<LineItem>?) {
        this.lineItemList = lineItemList
    }

    @XmlTransient
    fun getPricingModelList(): List<PricingModel>? {
        return pricingModelList
    }

    fun setPricingModelList(pricingModelList: List<PricingModel>?) {
        this.pricingModelList = pricingModelList
    }

    @XmlTransient
    fun getAdList(): List<Ad>? {
        return adList
    }

    fun setAdList(adList: List<Ad>?) {
        this.adList = adList
    }

    @XmlTransient
    fun getCustomFieldOptionList(): List<CustomFieldOption>? {
        return customFieldOptionList
    }

    fun setCustomFieldOptionList(customFieldOptionList: List<CustomFieldOption>?) {
        this.customFieldOptionList = customFieldOptionList
    }

    @XmlTransient
    fun getUseradwList(): List<Useradw>? {
        return useradwList
    }

    fun setUseradwList(useradwList: List<Useradw>?) {
        this.useradwList = useradwList
    }

    @XmlTransient
    fun getNewsletterOfferList(): List<NewsletterOffer>? {
        return newsletterOfferList
    }

    fun setNewsletterOfferList(newsletterOfferList: List<NewsletterOffer>?) {
        this.newsletterOfferList = newsletterOfferList
    }

    @XmlTransient
    fun getCampaignList(): List<Campaign>? {
        return campaignList
    }

    fun setCampaignList(campaignList: List<Campaign>?) {
        this.campaignList = campaignList
    }

    @XmlTransient
    fun getTopicList(): List<Topic>? {
        return topicList
    }

    fun setTopicList(topicList: List<Topic>?) {
        this.topicList = topicList
    }

    @XmlTransient
    fun getPlacementList(): List<Placement>? {
        return placementList
    }

    fun setPlacementList(placementList: List<Placement>?) {
        this.placementList = placementList
    }

    @XmlTransient
    fun getThirdPartyList(): List<ThirdParty>? {
        return thirdPartyList
    }

    fun setThirdPartyList(thirdPartyList: List<ThirdParty>?) {
        this.thirdPartyList = thirdPartyList
    }

    @XmlTransient
    fun getDfpCustomFieldList(): List<DfpCustomField>? {
        return dfpCustomFieldList
    }

    fun setDfpCustomFieldList(dfpCustomFieldList: List<DfpCustomField>?) {
        this.dfpCustomFieldList = dfpCustomFieldList
    }

    @XmlTransient
    fun getMeSoList(): List<MeSo>? {
        return meSoList
    }

    fun setMeSoList(meSoList: List<MeSo>?) {
        this.meSoList = meSoList
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    @XmlTransient
    fun getTargetGroupList(): List<TargetGroup>? {
        return targetGroupList
    }

    fun setTargetGroupList(targetGroupList: List<TargetGroup>?) {
        this.targetGroupList = targetGroupList
    }

    @XmlTransient
    fun getZeitPlanerList(): List<ZeitPlaner>? {
        return zeitPlanerList
    }

    fun setZeitPlanerList(zeitPlanerList: List<ZeitPlaner>?) {
        this.zeitPlanerList = zeitPlanerList
    }

    @XmlTransient
    fun getCustomFieldList(): List<CustomField>? {
        return customFieldList
    }

    fun setCustomFieldList(customFieldList: List<CustomField>?) {
        this.customFieldList = customFieldList
    }

    @XmlTransient
    fun getWebsiteList(): List<Website>? {
        return websiteList
    }

    fun setWebsiteList(websiteList: List<Website>?) {
        this.websiteList = websiteList
    }

    @XmlTransient
    fun getBusinessList(): List<Business>? {
        return businessList
    }

    fun setBusinessList(businessList: List<Business>?) {
        this.businessList = businessList
    }

    @XmlTransient
    fun getNewsletterServiceChargeList(): List<NewsletterServiceCharge>? {
        return newsletterServiceChargeList
    }

    fun setNewsletterServiceChargeList(newsletterServiceChargeList: List<NewsletterServiceCharge>?) {
        this.newsletterServiceChargeList = newsletterServiceChargeList
    }

    @XmlTransient
    fun getAdUnitList(): List<AdUnit>? {
        return adUnitList
    }

    fun setAdUnitList(adUnitList: List<AdUnit>?) {
        this.adUnitList = adUnitList
    }

    @XmlTransient
    fun getCarrierList(): List<Carrier>? {
        return carrierList
    }

    fun setCarrierList(carrierList: List<Carrier>?) {
        this.carrierList = carrierList
    }

    @XmlTransient
    fun getProductTypeList(): List<ProductType>? {
        return productTypeList
    }

    fun setProductTypeList(productTypeList: List<ProductType>?) {
        this.productTypeList = productTypeList
    }

    fun getCustomFieldId(): CustomField? {
        return customFieldId
    }

    fun setCustomFieldId(customFieldId: CustomField?) {
        this.customFieldId = customFieldId
    }

    fun getCustomFieldOptionId(): CustomFieldOption? {
        return customFieldOptionId
    }

    fun setCustomFieldOptionId(customFieldOptionId: CustomFieldOption?) {
        this.customFieldOptionId = customFieldOptionId
    }

    fun getModifierId(): User? {
        return modifierId
    }

    fun setModifierId(modifierId: User?) {
        this.modifierId = modifierId
    }

    fun getCreatorId(): User? {
        return creatorId
    }

    fun setCreatorId(creatorId: User?) {
        this.creatorId = creatorId
    }

    @XmlTransient
    fun getReportList(): List<Report>? {
        return reportList
    }

    fun setReportList(reportList: List<Report>?) {
        this.reportList = reportList
    }

    @XmlTransient
    fun getMagazineList(): List<Magazine>? {
        return magazineList
    }

    fun setMagazineList(magazineList: List<Magazine>?) {
        this.magazineList = magazineList
    }

    @XmlTransient
    fun getUserList(): List<User>? {
        return userList
    }

    fun setUserList(userList: List<User>?) {
        this.userList = userList
    }

    @XmlTransient
    fun getMyNewsletterOfferList(): List<MyNewsletterOffer>? {
        return myNewsletterOfferList
    }

    fun setMyNewsletterOfferList(myNewsletterOfferList: List<MyNewsletterOffer>?) {
        this.myNewsletterOfferList = myNewsletterOfferList
    }

    @XmlTransient
    fun getAdProductList(): List<AdProduct>? {
        return adProductList
    }

    fun setAdProductList(adProductList: List<AdProduct>?) {
        this.adProductList = adProductList
    }

    @XmlTransient
    fun getCustomerList(): List<Customer>? {
        return customerList
    }

    fun setCustomerList(customerList: List<Customer>?) {
        this.customerList = customerList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is ObjectInfo) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.ObjectInfo[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "office")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Office.findAll", query = "SELECT o FROM Office o"))
class Office : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @JoinColumn(name = "address_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var addressId: Address? = null

    @JoinColumn(name = "company_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var companyId: Company? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @OneToMany(mappedBy = "officeId", fetch = FetchType.LAZY)
    private var websiteList: List<Website>? = null

    @OneToMany(mappedBy = "officeId", fetch = FetchType.LAZY)
    private var userList: List<User>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, name: String?) {
        this.id = id
        this.version = version
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getAddressId(): Address? {
        return addressId
    }

    fun setAddressId(addressId: Address?) {
        this.addressId = addressId
    }

    fun getCompanyId(): Company? {
        return companyId
    }

    fun setCompanyId(companyId: Company?) {
        this.companyId = companyId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    @XmlTransient
    fun getWebsiteList(): List<Website>? {
        return websiteList
    }

    fun setWebsiteList(websiteList: List<Website>?) {
        this.websiteList = websiteList
    }

    @XmlTransient
    fun getUserList(): List<User>? {
        return userList
    }

    fun setUserList(userList: List<User>?) {
        this.userList = userList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Office) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Office[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "placement")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Placement.findAll", query = "SELECT p FROM Placement p"))
class Placement : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "ad_sense_targeting_locale")
    private var adSenseTargetingLocale: String? = null

    @Basic(optional = false)
    @Column(name = "description")
    private var description: String? = null

    @Basic(optional = false)
    @Column(name = "dfp_id")
    private var dfpId: String? = null

    @Column(name = "inventory_status")
    private var inventoryStatus: String? = null

    @Column(name = "is_ad_sense_targeting_enabled")
    private var isAdSenseTargetingEnabled: Boolean? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Basic(optional = false)
    @Column(name = "placement_code")
    private var placementCode: String? = null

    @Column(name = "targeting_ad_location")
    private var targetingAdLocation: String? = null

    @Column(name = "targeting_description")
    private var targetingDescription: String? = null

    @Column(name = "targeting_site_name")
    private var targetingSiteName: String? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, description: String?, dfpId: String?, name: String?, placementCode: String?) {
        this.id = id
        this.version = version
        this.description = description
        this.dfpId = dfpId
        this.name = name
        this.placementCode = placementCode
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getAdSenseTargetingLocale(): String? {
        return adSenseTargetingLocale
    }

    fun setAdSenseTargetingLocale(adSenseTargetingLocale: String?) {
        this.adSenseTargetingLocale = adSenseTargetingLocale
    }

    fun getDescription(): String? {
        return description
    }

    fun setDescription(description: String?) {
        this.description = description
    }

    fun getDfpId(): String? {
        return dfpId
    }

    fun setDfpId(dfpId: String?) {
        this.dfpId = dfpId
    }

    fun getInventoryStatus(): String? {
        return inventoryStatus
    }

    fun setInventoryStatus(inventoryStatus: String?) {
        this.inventoryStatus = inventoryStatus
    }

    fun getIsAdSenseTargetingEnabled(): Boolean? {
        return isAdSenseTargetingEnabled
    }

    fun setIsAdSenseTargetingEnabled(isAdSenseTargetingEnabled: Boolean?) {
        this.isAdSenseTargetingEnabled = isAdSenseTargetingEnabled
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getPlacementCode(): String? {
        return placementCode
    }

    fun setPlacementCode(placementCode: String?) {
        this.placementCode = placementCode
    }

    fun getTargetingAdLocation(): String? {
        return targetingAdLocation
    }

    fun setTargetingAdLocation(targetingAdLocation: String?) {
        this.targetingAdLocation = targetingAdLocation
    }

    fun getTargetingDescription(): String? {
        return targetingDescription
    }

    fun setTargetingDescription(targetingDescription: String?) {
        this.targetingDescription = targetingDescription
    }

    fun getTargetingSiteName(): String? {
        return targetingSiteName
    }

    fun setTargetingSiteName(targetingSiteName: String?) {
        this.targetingSiteName = targetingSiteName
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Placement) {
            return false
        }
        val other = `object`
        return if ((id == null && other.id != null || id != null) && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Placement[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
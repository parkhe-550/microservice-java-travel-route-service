/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "pricing_model")
@XmlRootElement
@NamedQueries(NamedQuery(name = "PricingModel.findAll", query = "SELECT p FROM PricingModel p"))
class PricingModel : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "area")
    private var area: String? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "cpm")
    private var cpm: BigDecimal? = null

    @Column(name = "fixed_price")
    private var fixedPrice: BigDecimal? = null

    @Column(name = "is_active")
    private var isActive: Boolean? = null

    @Basic(optional = false)
    @Column(name = "model_type")
    private var modelType: String? = null

    @Column(name = "concept")
    private var concept: BigDecimal? = null

    @Column(name = "content")
    private var content: BigDecimal? = null

    @Column(name = "diverse")
    private var diverse: BigDecimal? = null

    @Column(name = "plus")
    private var plus: BigDecimal? = null

    @Column(name = "premium_advertorial")
    private var premiumAdvertorial: BigDecimal? = null

    @JoinColumn(name = "ad_product_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var adProductId: AdProduct? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, area: String?, modelType: String?) {
        this.id = id
        this.version = version
        this.area = area
        this.modelType = modelType
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getArea(): String? {
        return area
    }

    fun setArea(area: String?) {
        this.area = area
    }

    fun getCpm(): BigDecimal? {
        return cpm
    }

    fun setCpm(cpm: BigDecimal?) {
        this.cpm = cpm
    }

    fun getFixedPrice(): BigDecimal? {
        return fixedPrice
    }

    fun setFixedPrice(fixedPrice: BigDecimal?) {
        this.fixedPrice = fixedPrice
    }

    fun getIsActive(): Boolean? {
        return isActive
    }

    fun setIsActive(isActive: Boolean?) {
        this.isActive = isActive
    }

    fun getModelType(): String? {
        return modelType
    }

    fun setModelType(modelType: String?) {
        this.modelType = modelType
    }

    fun getConcept(): BigDecimal? {
        return concept
    }

    fun setConcept(concept: BigDecimal?) {
        this.concept = concept
    }

    fun getContent(): BigDecimal? {
        return content
    }

    fun setContent(content: BigDecimal?) {
        this.content = content
    }

    fun getDiverse(): BigDecimal? {
        return diverse
    }

    fun setDiverse(diverse: BigDecimal?) {
        this.diverse = diverse
    }

    fun getPlus(): BigDecimal? {
        return plus
    }

    fun setPlus(plus: BigDecimal?) {
        this.plus = plus
    }

    fun getPremiumAdvertorial(): BigDecimal? {
        return premiumAdvertorial
    }

    fun setPremiumAdvertorial(premiumAdvertorial: BigDecimal?) {
        this.premiumAdvertorial = premiumAdvertorial
    }

    fun getAdProductId(): AdProduct? {
        return adProductId
    }

    fun setAdProductId(adProductId: AdProduct?) {
        this.adProductId = adProductId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is PricingModel) {
            return false
        }
        val other = `object`
        return if ((id == null && other.id != null || id != null) && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.PricingModel[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
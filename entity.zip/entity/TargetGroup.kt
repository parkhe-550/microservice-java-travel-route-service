/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "target_group")
@XmlRootElement
@NamedQueries(NamedQuery(name = "TargetGroup.findAll", query = "SELECT t FROM TargetGroup t"))
class TargetGroup : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "description")
    private var description: String? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(id: Long?, version: Long, description: String?, name: String?) {
        this.id = id
        this.version = version
        this.description = description
        this.name = name
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getDescription(): String? {
        return description
    }

    fun setDescription(description: String?) {
        this.description = description
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is TargetGroup) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.TargetGroup[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
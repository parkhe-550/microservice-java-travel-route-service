/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import java.math.BigDecimal
import java.util.*
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement

/**
 *
 * @author profp
 */
@Entity
@Table(name = "third_party")
@XmlRootElement
@NamedQueries(NamedQuery(name = "ThirdParty.findAll", query = "SELECT t FROM ThirdParty t"))
class ThirdParty : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Column(name = "active")
    private var active: Boolean? = null

    @Column(name = "bank_received_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var bankReceivedDate: Date? = null

    @Basic(optional = false)
    @Column(name = "booking_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var bookingDate: Date? = null

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "business_share")
    private var businessShare: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "credit_note")
    private var creditNote: String? = null

    @Basic(optional = false)
    @Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var endDate: Date? = null

    @Column(name = "gross_including_vat_amount")
    private var grossIncludingVatAmount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "name")
    private var name: String? = null

    @Basic(optional = false)
    @Column(name = "net_business_share_amount")
    private var netBusinessShareAmount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "received_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var receivedDate: Date? = null

    @Basic(optional = false)
    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private var startDate: Date? = null

    @Basic(optional = false)
    @Column(name = "subject")
    private var subject: String? = null

    @Basic(optional = false)
    @Column(name = "third_party_share")
    private var thirdPartyShare: BigDecimal? = null

    @Column(name = "third_party_share_amount")
    private var thirdPartyShareAmount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "total_net_amount")
    private var totalNetAmount: BigDecimal? = null

    @Basic(optional = false)
    @Column(name = "vat")
    private var vat: BigDecimal? = null

    @JoinColumn(name = "ad_product_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var adProductId: AdProduct? = null

    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var branchId: Branch? = null

    @JoinColumn(name = "business_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var businessId: Business? = null

    @JoinColumn(name = "third_party_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var thirdPartyId: Customer? = null

    @JoinColumn(name = "newsletter_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var newsletterId: Newsletter? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "salesman_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var salesmanId: User? = null

    @JoinColumn(name = "website_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var websiteId: Website? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        bookingDate: Date?,
        businessShare: BigDecimal?,
        creditNote: String?,
        endDate: Date?,
        name: String?,
        netBusinessShareAmount: BigDecimal?,
        receivedDate: Date?,
        startDate: Date?,
        subject: String?,
        thirdPartyShare: BigDecimal?,
        totalNetAmount: BigDecimal?,
        vat: BigDecimal?
    ) {
        this.id = id
        this.version = version
        this.bookingDate = bookingDate
        this.businessShare = businessShare
        this.creditNote = creditNote
        this.endDate = endDate
        this.name = name
        this.netBusinessShareAmount = netBusinessShareAmount
        this.receivedDate = receivedDate
        this.startDate = startDate
        this.subject = subject
        this.thirdPartyShare = thirdPartyShare
        this.totalNetAmount = totalNetAmount
        this.vat = vat
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getActive(): Boolean? {
        return active
    }

    fun setActive(active: Boolean?) {
        this.active = active
    }

    fun getBankReceivedDate(): Date? {
        return bankReceivedDate
    }

    fun setBankReceivedDate(bankReceivedDate: Date?) {
        this.bankReceivedDate = bankReceivedDate
    }

    fun getBookingDate(): Date? {
        return bookingDate
    }

    fun setBookingDate(bookingDate: Date?) {
        this.bookingDate = bookingDate
    }

    fun getBusinessShare(): BigDecimal? {
        return businessShare
    }

    fun setBusinessShare(businessShare: BigDecimal?) {
        this.businessShare = businessShare
    }

    fun getCreditNote(): String? {
        return creditNote
    }

    fun setCreditNote(creditNote: String?) {
        this.creditNote = creditNote
    }

    fun getEndDate(): Date? {
        return endDate
    }

    fun setEndDate(endDate: Date?) {
        this.endDate = endDate
    }

    fun getGrossIncludingVatAmount(): BigDecimal? {
        return grossIncludingVatAmount
    }

    fun setGrossIncludingVatAmount(grossIncludingVatAmount: BigDecimal?) {
        this.grossIncludingVatAmount = grossIncludingVatAmount
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String?) {
        this.name = name
    }

    fun getNetBusinessShareAmount(): BigDecimal? {
        return netBusinessShareAmount
    }

    fun setNetBusinessShareAmount(netBusinessShareAmount: BigDecimal?) {
        this.netBusinessShareAmount = netBusinessShareAmount
    }

    fun getReceivedDate(): Date? {
        return receivedDate
    }

    fun setReceivedDate(receivedDate: Date?) {
        this.receivedDate = receivedDate
    }

    fun getStartDate(): Date? {
        return startDate
    }

    fun setStartDate(startDate: Date?) {
        this.startDate = startDate
    }

    fun getSubject(): String? {
        return subject
    }

    fun setSubject(subject: String?) {
        this.subject = subject
    }

    fun getThirdPartyShare(): BigDecimal? {
        return thirdPartyShare
    }

    fun setThirdPartyShare(thirdPartyShare: BigDecimal?) {
        this.thirdPartyShare = thirdPartyShare
    }

    fun getThirdPartyShareAmount(): BigDecimal? {
        return thirdPartyShareAmount
    }

    fun setThirdPartyShareAmount(thirdPartyShareAmount: BigDecimal?) {
        this.thirdPartyShareAmount = thirdPartyShareAmount
    }

    fun getTotalNetAmount(): BigDecimal? {
        return totalNetAmount
    }

    fun setTotalNetAmount(totalNetAmount: BigDecimal?) {
        this.totalNetAmount = totalNetAmount
    }

    fun getVat(): BigDecimal? {
        return vat
    }

    fun setVat(vat: BigDecimal?) {
        this.vat = vat
    }

    fun getAdProductId(): AdProduct? {
        return adProductId
    }

    fun setAdProductId(adProductId: AdProduct?) {
        this.adProductId = adProductId
    }

    fun getBranchId(): Branch? {
        return branchId
    }

    fun setBranchId(branchId: Branch?) {
        this.branchId = branchId
    }

    fun getBusinessId(): Business? {
        return businessId
    }

    fun setBusinessId(businessId: Business?) {
        this.businessId = businessId
    }

    fun getThirdPartyId(): Customer? {
        return thirdPartyId
    }

    fun setThirdPartyId(thirdPartyId: Customer?) {
        this.thirdPartyId = thirdPartyId
    }

    fun getNewsletterId(): Newsletter? {
        return newsletterId
    }

    fun setNewsletterId(newsletterId: Newsletter?) {
        this.newsletterId = newsletterId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getSalesmanId(): User? {
        return salesmanId
    }

    fun setSalesmanId(salesmanId: User?) {
        this.salesmanId = salesmanId
    }

    fun getWebsiteId(): Website? {
        return websiteId
    }

    fun setWebsiteId(websiteId: Website?) {
        this.websiteId = websiteId
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is ThirdParty) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.ThirdParty[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
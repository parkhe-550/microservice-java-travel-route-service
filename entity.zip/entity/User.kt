/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "user")
@XmlRootElement
@NamedQueries(NamedQuery(name = "User.findAll", query = "SELECT u FROM User u"))
class User : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "email")
    private var email: String? = null

    @Basic(optional = false)
    @Column(name = "enabled")
    private var enabled = false

    @Basic(optional = false)
    @Column(name = "fax")
    private var fax: String? = null

    @Basic(optional = false)
    @Column(name = "first_name")
    private var firstName: String? = null

    @Basic(optional = false)
    @Column(name = "last_name")
    private var lastName: String? = null

    @Basic(optional = false)
    @Column(name = "login")
    private var login: String? = null

    @Basic(optional = false)
    @Column(name = "password")
    private var password: String? = null

    @Basic(optional = false)
    @Column(name = "phone")
    private var phone: String? = null

    @Basic(optional = false)
    @Column(name = "role")
    private var role: String? = null

    @Basic(optional = false)
    @Column(name = "salutation")
    private var salutation: String? = null

    @Basic(optional = false)
    @Column(name = "title")
    private var title: String? = null

    @Column(name = "ticker_email")
    private var tickerEmail: Boolean? = null

    @Column(name = "is_in_media_online")
    private var isInMediaOnline: Boolean? = null

    @Column(name = "is_in_media_print")
    private var isInMediaPrint: Boolean? = null

    @Lob
    @Column(name = "email_signature")
    private var emailSignature: String? = null

    @Column(name = "is_dfp_user")
    private var isDfpUser: Boolean? = null

    @Column(name = "media_suite_short_name")
    private var mediaSuiteShortName: String? = null

    @Column(name = "dfp_email")
    private var dfpEmail: String? = null

    @Column(name = "org_email")
    private var orgEmail: String? = null

    @Column(name = "old_password")
    private var oldPassword: String? = null

    @Column(name = "username")
    private var username: String? = null

    @Basic(optional = false)
    @Column(name = "account_non_expired")
    private var accountNonExpired = false

    @Basic(optional = false)
    @Column(name = "account_non_locked")
    private var accountNonLocked = false

    @Basic(optional = false)
    @Column(name = "credentials_non_expired")
    private var credentialsNonExpired = false

    @Column(name = "initials")
    private var initials: String? = null

    @OneToMany(mappedBy = "salesmanId", fetch = FetchType.LAZY)
    private var newsletterOfferList: List<NewsletterOffer>? = null

    @OneToMany(mappedBy = "adOpsUserId", fetch = FetchType.LAZY)
    private var newsletterOfferList1: List<NewsletterOffer>? = null

    @OneToMany(mappedBy = "adOpsUserId", fetch = FetchType.LAZY)
    private var campaignList: List<Campaign>? = null

    @OneToMany(mappedBy = "salesmanId", fetch = FetchType.LAZY)
    private var campaignList1: List<Campaign>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "salesmanId", fetch = FetchType.LAZY)
    private var thirdPartyList: List<ThirdParty>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "salesmanId", fetch = FetchType.LAZY)
    private var meSoList: List<MeSo>? = null

    @OneToMany(mappedBy = "kamId", fetch = FetchType.LAZY)
    private var meSoList1: List<MeSo>? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "user", fetch = FetchType.LAZY)
    private var userRoleList: List<UserRole>? = null

    @OneToMany(mappedBy = "salesmanId", fetch = FetchType.LAZY)
    private var custNewsPriceList: List<CustNewsPrice>? = null

    @OneToMany(mappedBy = "modifierId", fetch = FetchType.LAZY)
    private var objectInfoList: List<ObjectInfo>? = null

    @OneToMany(mappedBy = "creatorId", fetch = FetchType.LAZY)
    private var objectInfoList1: List<ObjectInfo>? = null

    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var branchId: Branch? = null

    @JoinColumn(name = "business_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var businessId: Business? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @JoinColumn(name = "office_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var officeId: Office? = null

    @OneToMany(mappedBy = "adManagerId", fetch = FetchType.LAZY)
    private var userList: List<User>? = null

    @JoinColumn(name = "ad_manager_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var adManagerId: User? = null

    @OneToMany(mappedBy = "bossId", fetch = FetchType.LAZY)
    private var userList1: List<User>? = null

    @JoinColumn(name = "boss_id", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private var bossId: User? = null

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "userId", fetch = FetchType.LAZY)
    private var myNewsletterOfferList: List<MyNewsletterOffer>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        email: String?,
        enabled: Boolean,
        fax: String?,
        firstName: String?,
        lastName: String?,
        login: String?,
        password: String?,
        phone: String?,
        role: String?,
        salutation: String?,
        title: String?,
        accountNonExpired: Boolean,
        accountNonLocked: Boolean,
        credentialsNonExpired: Boolean
    ) {
        this.id = id
        this.version = version
        this.email = email
        this.enabled = enabled
        this.fax = fax
        this.firstName = firstName
        this.lastName = lastName
        this.login = login
        this.password = password
        this.phone = phone
        this.role = role
        this.salutation = salutation
        this.title = title
        this.accountNonExpired = accountNonExpired
        this.accountNonLocked = accountNonLocked
        this.credentialsNonExpired = credentialsNonExpired
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getEmail(): String? {
        return email
    }

    fun setEmail(email: String?) {
        this.email = email
    }

    fun getEnabled(): Boolean {
        return enabled
    }

    fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    fun getFax(): String? {
        return fax
    }

    fun setFax(fax: String?) {
        this.fax = fax
    }

    fun getFirstName(): String? {
        return firstName
    }

    fun setFirstName(firstName: String?) {
        this.firstName = firstName
    }

    fun getLastName(): String? {
        return lastName
    }

    fun setLastName(lastName: String?) {
        this.lastName = lastName
    }

    fun getLogin(): String? {
        return login
    }

    fun setLogin(login: String?) {
        this.login = login
    }

    fun getPassword(): String? {
        return password
    }

    fun setPassword(password: String?) {
        this.password = password
    }

    fun getPhone(): String? {
        return phone
    }

    fun setPhone(phone: String?) {
        this.phone = phone
    }

    fun getRole(): String? {
        return role
    }

    fun setRole(role: String?) {
        this.role = role
    }

    fun getSalutation(): String? {
        return salutation
    }

    fun setSalutation(salutation: String?) {
        this.salutation = salutation
    }

    fun getTitle(): String? {
        return title
    }

    fun setTitle(title: String?) {
        this.title = title
    }

    fun getTickerEmail(): Boolean? {
        return tickerEmail
    }

    fun setTickerEmail(tickerEmail: Boolean?) {
        this.tickerEmail = tickerEmail
    }

    fun getIsInMediaOnline(): Boolean? {
        return isInMediaOnline
    }

    fun setIsInMediaOnline(isInMediaOnline: Boolean?) {
        this.isInMediaOnline = isInMediaOnline
    }

    fun getIsInMediaPrint(): Boolean? {
        return isInMediaPrint
    }

    fun setIsInMediaPrint(isInMediaPrint: Boolean?) {
        this.isInMediaPrint = isInMediaPrint
    }

    fun getEmailSignature(): String? {
        return emailSignature
    }

    fun setEmailSignature(emailSignature: String?) {
        this.emailSignature = emailSignature
    }

    fun getIsDfpUser(): Boolean? {
        return isDfpUser
    }

    fun setIsDfpUser(isDfpUser: Boolean?) {
        this.isDfpUser = isDfpUser
    }

    fun getMediaSuiteShortName(): String? {
        return mediaSuiteShortName
    }

    fun setMediaSuiteShortName(mediaSuiteShortName: String?) {
        this.mediaSuiteShortName = mediaSuiteShortName
    }

    fun getDfpEmail(): String? {
        return dfpEmail
    }

    fun setDfpEmail(dfpEmail: String?) {
        this.dfpEmail = dfpEmail
    }

    fun getOrgEmail(): String? {
        return orgEmail
    }

    fun setOrgEmail(orgEmail: String?) {
        this.orgEmail = orgEmail
    }

    fun getOldPassword(): String? {
        return oldPassword
    }

    fun setOldPassword(oldPassword: String?) {
        this.oldPassword = oldPassword
    }

    fun getUsername(): String? {
        return username
    }

    fun setUsername(username: String?) {
        this.username = username
    }

    fun getAccountNonExpired(): Boolean {
        return accountNonExpired
    }

    fun setAccountNonExpired(accountNonExpired: Boolean) {
        this.accountNonExpired = accountNonExpired
    }

    fun getAccountNonLocked(): Boolean {
        return accountNonLocked
    }

    fun setAccountNonLocked(accountNonLocked: Boolean) {
        this.accountNonLocked = accountNonLocked
    }

    fun getCredentialsNonExpired(): Boolean {
        return credentialsNonExpired
    }

    fun setCredentialsNonExpired(credentialsNonExpired: Boolean) {
        this.credentialsNonExpired = credentialsNonExpired
    }

    fun getInitials(): String? {
        return initials
    }

    fun setInitials(initials: String?) {
        this.initials = initials
    }

    @XmlTransient
    fun getNewsletterOfferList(): List<NewsletterOffer>? {
        return newsletterOfferList
    }

    fun setNewsletterOfferList(newsletterOfferList: List<NewsletterOffer>?) {
        this.newsletterOfferList = newsletterOfferList
    }

    @XmlTransient
    fun getNewsletterOfferList1(): List<NewsletterOffer>? {
        return newsletterOfferList1
    }

    fun setNewsletterOfferList1(newsletterOfferList1: List<NewsletterOffer>?) {
        this.newsletterOfferList1 = newsletterOfferList1
    }

    @XmlTransient
    fun getCampaignList(): List<Campaign>? {
        return campaignList
    }

    fun setCampaignList(campaignList: List<Campaign>?) {
        this.campaignList = campaignList
    }

    @XmlTransient
    fun getCampaignList1(): List<Campaign>? {
        return campaignList1
    }

    fun setCampaignList1(campaignList1: List<Campaign>?) {
        this.campaignList1 = campaignList1
    }

    @XmlTransient
    fun getThirdPartyList(): List<ThirdParty>? {
        return thirdPartyList
    }

    fun setThirdPartyList(thirdPartyList: List<ThirdParty>?) {
        this.thirdPartyList = thirdPartyList
    }

    @XmlTransient
    fun getMeSoList(): List<MeSo>? {
        return meSoList
    }

    fun setMeSoList(meSoList: List<MeSo>?) {
        this.meSoList = meSoList
    }

    @XmlTransient
    fun getMeSoList1(): List<MeSo>? {
        return meSoList1
    }

    fun setMeSoList1(meSoList1: List<MeSo>?) {
        this.meSoList1 = meSoList1
    }

    @XmlTransient
    fun getUserRoleList(): List<UserRole>? {
        return userRoleList
    }

    fun setUserRoleList(userRoleList: List<UserRole>?) {
        this.userRoleList = userRoleList
    }

    @XmlTransient
    fun getCustNewsPriceList(): List<CustNewsPrice>? {
        return custNewsPriceList
    }

    fun setCustNewsPriceList(custNewsPriceList: List<CustNewsPrice>?) {
        this.custNewsPriceList = custNewsPriceList
    }

    @XmlTransient
    fun getObjectInfoList(): List<ObjectInfo>? {
        return objectInfoList
    }

    fun setObjectInfoList(objectInfoList: List<ObjectInfo>?) {
        this.objectInfoList = objectInfoList
    }

    @XmlTransient
    fun getObjectInfoList1(): List<ObjectInfo>? {
        return objectInfoList1
    }

    fun setObjectInfoList1(objectInfoList1: List<ObjectInfo>?) {
        this.objectInfoList1 = objectInfoList1
    }

    fun getBranchId(): Branch? {
        return branchId
    }

    fun setBranchId(branchId: Branch?) {
        this.branchId = branchId
    }

    fun getBusinessId(): Business? {
        return businessId
    }

    fun setBusinessId(businessId: Business?) {
        this.businessId = businessId
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    fun getOfficeId(): Office? {
        return officeId
    }

    fun setOfficeId(officeId: Office?) {
        this.officeId = officeId
    }

    @XmlTransient
    fun getUserList(): List<User>? {
        return userList
    }

    fun setUserList(userList: List<User>?) {
        this.userList = userList
    }

    fun getAdManagerId(): User? {
        return adManagerId
    }

    fun setAdManagerId(adManagerId: User?) {
        this.adManagerId = adManagerId
    }

    @XmlTransient
    fun getUserList1(): List<User>? {
        return userList1
    }

    fun setUserList1(userList1: List<User>?) {
        this.userList1 = userList1
    }

    fun getBossId(): User? {
        return bossId
    }

    fun setBossId(bossId: User?) {
        this.bossId = bossId
    }

    @XmlTransient
    fun getMyNewsletterOfferList(): List<MyNewsletterOffer>? {
        return myNewsletterOfferList
    }

    fun setMyNewsletterOfferList(myNewsletterOfferList: List<MyNewsletterOffer>?) {
        this.myNewsletterOfferList = myNewsletterOfferList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is User) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.User[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
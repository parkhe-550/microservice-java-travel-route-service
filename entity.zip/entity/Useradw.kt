/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.snd.adcomm.ad.api.entity

import java.io.Serializable
import javax.persistence.*
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlTransient

/**
 *
 * @author profp
 */
@Entity
@Table(name = "useradw")
@XmlRootElement
@NamedQueries(NamedQuery(name = "Useradw.findAll", query = "SELECT u FROM Useradw u"))
class Useradw : Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private var id: Long? = null

    @Basic(optional = false)
    @Column(name = "version")
    private var version: Long = 0

    @Basic(optional = false)
    @Column(name = "company")
    private var company: String? = null

    @Basic(optional = false)
    @Column(name = "enabled")
    private var enabled = false

    @Basic(optional = false)
    @Column(name = "first_name")
    private var firstName: String? = null

    @Basic(optional = false)
    @Column(name = "ident_key")
    private var identKey: String? = null

    @Basic(optional = false)
    @Column(name = "last_name")
    private var lastName: String? = null

    @Column(name = "passwd")
    private var passwd: String? = null

    @Column(name = "phone")
    private var phone: String? = null

    @Basic(optional = false)
    @Column(name = "salutation")
    private var salutation: String? = null

    @Basic(optional = false)
    @Column(name = "username")
    private var username: String? = null

    @Lob
    @Column(name = "email_signature")
    private var emailSignature: String? = null

    @Column(name = "account_non_expired")
    private var accountNonExpired: Boolean? = null

    @Column(name = "account_non_locked")
    private var accountNonLocked: Boolean? = null

    @Column(name = "credentials_non_expired")
    private var credentialsNonExpired: Boolean? = null

    @Column(name = "password")
    private var password: String? = null

    @Column(name = "group_email")
    private var groupEmail: String? = null

    @Column(name = "default_mail_send")
    private var defaultMailSend: Boolean? = null

    @ManyToMany(mappedBy = "useradwList", fetch = FetchType.LAZY)
    private var roleadwList: List<Roleadw>? = null

    @OneToMany(mappedBy = "approverId", fetch = FetchType.LAZY)
    private var approvalLogList: List<ApprovalLog>? = null

    @OneToMany(mappedBy = "lastModifierId", fetch = FetchType.LAZY)
    private var adArchiveList: List<AdArchive>? = null

    @OneToMany(mappedBy = "createdById", fetch = FetchType.LAZY)
    private var adList: List<Ad>? = null

    @OneToMany(mappedBy = "publishedById", fetch = FetchType.LAZY)
    private var adList1: List<Ad>? = null

    @OneToMany(mappedBy = "lastModifierId", fetch = FetchType.LAZY)
    private var adList2: List<Ad>? = null

    @JoinColumn(name = "info_id", referencedColumnName = "id")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private var infoId: ObjectInfo? = null

    @OneToMany(mappedBy = "useradwId", fetch = FetchType.LAZY)
    private var newsletterOfferList: List<NewsletterOffer>? = null

    constructor() {}
    constructor(id: Long?) {
        this.id = id
    }

    constructor(
        id: Long?,
        version: Long,
        company: String?,
        enabled: Boolean,
        firstName: String?,
        identKey: String?,
        lastName: String?,
        salutation: String?,
        username: String?
    ) {
        this.id = id
        this.version = version
        this.company = company
        this.enabled = enabled
        this.firstName = firstName
        this.identKey = identKey
        this.lastName = lastName
        this.salutation = salutation
        this.username = username
    }

    fun getId(): Long? {
        return id
    }

    fun setId(id: Long?) {
        this.id = id
    }

    fun getVersion(): Long {
        return version
    }

    fun setVersion(version: Long) {
        this.version = version
    }

    fun getCompany(): String? {
        return company
    }

    fun setCompany(company: String?) {
        this.company = company
    }

    fun getEnabled(): Boolean {
        return enabled
    }

    fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    fun getFirstName(): String? {
        return firstName
    }

    fun setFirstName(firstName: String?) {
        this.firstName = firstName
    }

    fun getIdentKey(): String? {
        return identKey
    }

    fun setIdentKey(identKey: String?) {
        this.identKey = identKey
    }

    fun getLastName(): String? {
        return lastName
    }

    fun setLastName(lastName: String?) {
        this.lastName = lastName
    }

    fun getPasswd(): String? {
        return passwd
    }

    fun setPasswd(passwd: String?) {
        this.passwd = passwd
    }

    fun getPhone(): String? {
        return phone
    }

    fun setPhone(phone: String?) {
        this.phone = phone
    }

    fun getSalutation(): String? {
        return salutation
    }

    fun setSalutation(salutation: String?) {
        this.salutation = salutation
    }

    fun getUsername(): String? {
        return username
    }

    fun setUsername(username: String?) {
        this.username = username
    }

    fun getEmailSignature(): String? {
        return emailSignature
    }

    fun setEmailSignature(emailSignature: String?) {
        this.emailSignature = emailSignature
    }

    fun getAccountNonExpired(): Boolean? {
        return accountNonExpired
    }

    fun setAccountNonExpired(accountNonExpired: Boolean?) {
        this.accountNonExpired = accountNonExpired
    }

    fun getAccountNonLocked(): Boolean? {
        return accountNonLocked
    }

    fun setAccountNonLocked(accountNonLocked: Boolean?) {
        this.accountNonLocked = accountNonLocked
    }

    fun getCredentialsNonExpired(): Boolean? {
        return credentialsNonExpired
    }

    fun setCredentialsNonExpired(credentialsNonExpired: Boolean?) {
        this.credentialsNonExpired = credentialsNonExpired
    }

    fun getPassword(): String? {
        return password
    }

    fun setPassword(password: String?) {
        this.password = password
    }

    fun getGroupEmail(): String? {
        return groupEmail
    }

    fun setGroupEmail(groupEmail: String?) {
        this.groupEmail = groupEmail
    }

    fun getDefaultMailSend(): Boolean? {
        return defaultMailSend
    }

    fun setDefaultMailSend(defaultMailSend: Boolean?) {
        this.defaultMailSend = defaultMailSend
    }

    @XmlTransient
    fun getRoleadwList(): List<Roleadw>? {
        return roleadwList
    }

    fun setRoleadwList(roleadwList: List<Roleadw>?) {
        this.roleadwList = roleadwList
    }

    @XmlTransient
    fun getApprovalLogList(): List<ApprovalLog>? {
        return approvalLogList
    }

    fun setApprovalLogList(approvalLogList: List<ApprovalLog>?) {
        this.approvalLogList = approvalLogList
    }

    @XmlTransient
    fun getAdArchiveList(): List<AdArchive>? {
        return adArchiveList
    }

    fun setAdArchiveList(adArchiveList: List<AdArchive>?) {
        this.adArchiveList = adArchiveList
    }

    @XmlTransient
    fun getAdList(): List<Ad>? {
        return adList
    }

    fun setAdList(adList: List<Ad>?) {
        this.adList = adList
    }

    @XmlTransient
    fun getAdList1(): List<Ad>? {
        return adList1
    }

    fun setAdList1(adList1: List<Ad>?) {
        this.adList1 = adList1
    }

    @XmlTransient
    fun getAdList2(): List<Ad>? {
        return adList2
    }

    fun setAdList2(adList2: List<Ad>?) {
        this.adList2 = adList2
    }

    fun getInfoId(): ObjectInfo? {
        return infoId
    }

    fun setInfoId(infoId: ObjectInfo?) {
        this.infoId = infoId
    }

    @XmlTransient
    fun getNewsletterOfferList(): List<NewsletterOffer>? {
        return newsletterOfferList
    }

    fun setNewsletterOfferList(newsletterOfferList: List<NewsletterOffer>?) {
        this.newsletterOfferList = newsletterOfferList
    }

    override fun hashCode(): Int {
        var hash = 0
        hash += if (id != null) id.hashCode() else 0
        return hash
    }

    override fun equals(`object`: Any?): Boolean {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (`object` !is Useradw) {
            return false
        }
        val other = `object`
        return if (id == null && other.id != null || id != null && id != other.id) {
            false
        } else true
    }

    override fun toString(): String {
        return "org.snd.adcomm.ad.api.entity;.Useradw[ id=$id ]"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}